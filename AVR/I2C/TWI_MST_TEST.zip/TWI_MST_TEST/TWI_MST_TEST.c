#define F_CPU 8000000

#include <avr/io.h>
#include <util/delay.h>

#include "kvr/usart.h"

int twi_mst_write_byte(uint8_t,uint8_t);
uint8_t twi_mst_read_byte(uint8_t);
int twi_mst_write_str(int*,uint8_t);

int main(void)
{
	uint8_t data=5;
	long address;
	char test[64]={"abcdefghigklmnopqrstuvwxyz\nyamamoto tatsuya\nsakura\n"};
	char test2[64];
	uint8_t getdata;
	//�|�[�g�̓��o�͂̐ݒ�
	DDRB = 0xff;
	DDRC = 0b11001111;
	DDRD = 0xff;
	PORTC = 00110000;
	MCUCR = 0;
	
	//PWM�̐ݒ�

	//OCR0A,OCR0B �̐ݒ�
	TCCR0A = 0b10100011;
	TCCR0B = 0b00000001;

	//OCR1A,OCR1B �̐ݒ�
	TCCR1A = 0b10100011;
	TCCR1B = 0b00000001;

	//OCR2A,OCR2B �̐ݒ�
	TCCR2A = 0b10110011;
	TCCR2B = 0b00000001;

	
	// USART0, 9600 bps
	usart_init(0, 38400);
	// USART0 ��W���o�͂ɐݒ�
	usart_stdout(0);
	// TWI�� SCL���g���� 200kHz�ɐݒ�
	twi_mst_init(400000);
	
	//�}�C�R�����艻�����邽�ߑҋ@
	_delay_ms(100);
	address = 0;
	printf("\rprogram start\r");
	while(1)
	{
		if(data<100)
		{
			data++;
		}
		else
		{
			data = 0;
		}
		twi_mst_write_byte(data,0);
		printf("%d--%d\r",data,twi_mst_read_byte(0));
	}
}



/*----------------------TWI�呕�u�֐�----------------------*/
//TWI�呕�u�����񑗐M
int twi_mst_write_str(int* str1,uint8_t address)
{
	while(*str1 != '\0')
	{
		if(twi_mst_write_byte(*str1,address) == 0)
		{
			str1++;
		}
		else
		{
			break;
		}
		twi_mst_write_byte('\0',address);
	}
}
//TWI�呕�u1�o�C�g��������
inline int twi_mst_write_byte(uint8_t data,uint8_t address)
{
	twi_mst_start();
	if((twi_mst_write_slave_address(address)) == 0)
	{
		twi_mst_write_data(data);
		twi_mst_end();
		return 0;
	}
	else
	{
		twi_mst_end();
		return -1;
	}
}
//TWI�呕�u1�o�C�g�ǂݍ���
inline uint8_t twi_mst_read_byte(uint8_t address)
{
	uint8_t getdata;
	twi_mst_start();
	if((twi_mst_read_slave_address(address)) == 0)
	{
		getdata = twi_mst_read_data_noack();
		twi_mst_end();
		return getdata;
	}
	else
	{
		twi_mst_end();
		return -1;
	}
}


// TWI�呕�u�������֐�
void twi_mst_init(uint16_t f)
{
	//TWI����(SCL���g�� = CPU���g��/(16+2*(TWBR)�~�O�u�����l)
	TWSR = 0;
	TWBR = F_CPU/(2*f)-8;
}

//TWI�呕�u�J�n�����o�͊֐�
inline void twi_mst_start()
{
	TWCR = (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);
	while(!( TWCR & (1<<TWINT)))
	{
		if((TWSR & 0xF8 ) == 0x00)
		{
			TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
			break;
		}
	}
	//printf("%x\r",TWSR);
	//printf("I2C MST START\r");
}

//TWI�呕�u�I�������o�͊֐�
inline void twi_mst_end()
{
	TWCR = (1<<TWINT)|(1<<TWSTO)|(1<<TWEN);
	while(!( TWCR & (1<<TWSTO)));
	while((TWSR & 0xF8 ) != 0xF8 );
}

//TWI�呕�u���M�A�h���X�w��
inline int twi_mst_write_slave_address(int add)
{
	while((TWSR & 0xF8 ) != 0x08)
	{
		if((TWSR & 0xF8 ) == 0x00)
		{
			TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
			break;
		}
	}
	TWDR = add<<1;
	TWCR = (1<<TWINT)|(1<<TWEN);
	while(!( TWCR & ( 1<<TWINT)))
	{
		if((TWSR & 0xF8 ) == 0x00)
		{
			TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
			break;
		}
	}
	if(( TWSR & 0xF8 ) != 0x18 )
	{
		return -1;
	}
	return 0;
}

//TWI�呕�u��M�A�h���X�w��
inline int twi_mst_read_slave_address(int add)
{
	while((TWSR & 0xF8 ) != 0x08)
	{
		if((TWSR & 0xF8 ) == 0x00)
		{
			TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
			break;
		}
	}
	TWDR = (add<<1)+1;
	TWCR = (1<<TWINT)|(1<<TWEN);
	while(!(TWCR & (1<<TWINT)))
	{
		if((TWSR & 0xF8 ) == 0x00)
		{
			TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
			break;
		}
	}
	if(( TWSR & 0xF8 ) != 0x40 )
	{
		return -1;
	}
	return 0;
}

//TWI�呕�u���M
inline int twi_mst_write_data(int data)
{
	TWDR = data;
	TWCR = (1<<TWINT)|(1<<TWEN);
	while(!(TWCR & (1<<TWINT)))
	{
		if((TWSR & 0xF8 ) == 0x00)
		{
			TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
			break;
		}
	}
	if(( TWSR & 0xF8 ) != 0x30 )
	{
		//printf("write data BAD\r");
		//printf("%x\r",TWSR);
		return 1;
	}
	//printf("write data OK\r");
	return 0;
}

//TWI�呕�u��MNACK����
inline int twi_mst_read_data_noack()
{
	TWCR = (1<<TWINT)|(1<<TWEN);
	while(!(TWCR & (1<<TWINT)))
	{
		if((TWSR & 0xF8 ) == 0x00)
		{
			TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
			break;
		}
	}
	if(( TWSR & 0xF8 ) != 0x58 )
	{
		return 1;
	}
	return TWDR;
}

//TWI�呕�u��MACK����
inline int twi_mst_read_data_ack()
{
	TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWEA);
	while(!(TWCR & (1<<TWINT)))
	{
		if((TWSR & 0xF8 ) == 0x00)
		{
			TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
			break;
		}
	}
	if(( TWSR & 0xF8 ) != 0x50 )
	{
		return 1;
	}
	return TWDR;
}




