// ======================================================================
// xkvr (XMEGA KUT AVR Library) / pwm.h / v1.0
// PWM ライブラリ
// ======================================================================
//
// * PWM の初期化
//   第一引数には、&TCC0, &TCC1, &TCD0, &TCE0, &TCF0 のどれかを指定します。
//   第二引数には、PWM を有効にするポートを4 ビットで指定します。
//   
//   void pwm_init(PWM のポートのアドレス, 有効ポート);
// 
// ======================================================================
// 動作確認環境: ATxmega128D3 @ 32 MHz
// ======================================================================

#ifndef __XKVR_PWM__
#define __XKVR_PWM__

// 32 MHz でない場合警告を出す
#if F_CPU != 32000000
#error "The clock of 32 MHz is only supported."
#endif

#define XKVR_PWM_VERSION 10000UL

#include <avr/io.h>

void pwm_init(void * const tc, const uint8_t pin){
	
#if defined(__AVR_ATxmega64D3__)  || \
	defined(__AVR_ATxmega128D3__) || \
	defined(__AVR_ATxmega192D3__) || \
	defined(__AVR_ATxmega256D3__)
	
	// TCC0 (ポートC; OC0A, OC0B, OC0C, OC0D) の設定
	if(tc == &TCC0){
		TCC0.PER   = 0x00ff; // おまじない
		TCC0.CTRLA = TC_CLKSEL_DIV64_gc; // 256 分周
		TCC0.CTRLB = TC_WGMODE_SS_gc | (pin << 4); // 波形 & 有効ポートの設定
	}
	
	// TCC1 (ポートC; OC1A, OC1B) の設定
	else if(tc == &TCC1){
		TCC1.PER   = 0x00ff; // おまじない
		TCC1.CTRLA = TC_CLKSEL_DIV64_gc; // 256 分周
		TCC1.CTRLB = TC_WGMODE_SS_gc | (pin << 4); // 波形 & 有効ポートの設定
	}
	
	// TCD0 (ポートD; OC0A, OC0B, OC0C, OC0D) の設定
	else if(tc == &TCD0){
		TCD0.PER   = 0x00ff; // おまじない
		TCD0.CTRLA = TC_CLKSEL_DIV64_gc; // 256 分周
		TCD0.CTRLB = TC_WGMODE_SS_gc | (pin << 4); // 波形 & 有効ポートの設定
	}
	
	// TCE0 (ポートE; OC0A, OC0B, OC0C, OC0D) の設定
	else if(tc == &TCE0){
		TCE0.PER   = 0x00ff; // おまじない
		TCE0.CTRLA = TC_CLKSEL_DIV64_gc; // 256 分周
		TCE0.CTRLB = TC_WGMODE_SS_gc | (pin << 4); // 波形 & 有効ポートの設定
	}
	
	// TCF0 (ポートF; OC0A, OC0B, OC0C, OC0D) の設定
	else {
		TCF0.PER   = 0x00ff; // おまじない
		TCF0.CTRLA = TC_CLKSEL_DIV64_gc; // 64 分周
		TCF0.CTRLB = TC_WGMODE_SS_gc | (pin << 4); // 波形 & 有効ポートの設定
	}
	
#endif
	
}

#endif

// vim: se noet ts=4 sw=4 sts=0 ft=c :
