/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include<stdio.h>
#include <stdlib.h>

#define ACS_SENS 1.116071	//56mV/A

int main()
{
	int count;
	char buffer[64];
	int16 output;
	uint8 i;
	uint16 pwm = 0;
	uint16 pwmd = 0;
	uint8 ibuffer[64];
	double kp;
	int16 d;
	ibuffer[1] = '\0';
	
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
	CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
	USBUART_1_Start(0,USBUART_1_5V_OPERATION );
	PWM_1_Start();
	ADC_DelSig_1_Start();
	ADC_DelSig_1_StartConvert();
	
	/* Wait for Device to enumerate */
    while(!USBUART_1_GetConfiguration());
	
	USBUART_1_CDC_Init();

	while(1)
	{
		if(ADC_DelSig_1_IsEndConversion(ADC_DelSig_1_RETURN_STATUS))
        {
            output = ADC_DelSig_1_GetResult16()*ACS_SENS-250;
			if(output < pwm*50-20)
			{
				if(pwmd < 10000)
				{
					PWM_1_WriteCompare((uint16)(pwmd+=2));
				}
			}
			else if(output > pwm*50+20)
			{
				if(pwmd > 1)
				{
					PWM_1_WriteCompare((uint16)(pwmd-=2));
				}
			}
        }
		sprintf(buffer,"ACS0 = %4d[mA]  PWM = %d[mA] pwmd = %d\n",(int16)(output),(uint16)pwm*50,(uint16)pwmd);
		while(USBUART_1_CDCIsReady() == 0u);
		USBUART_1_PutString(buffer);
		if(USBUART_1_DataIsReady() != 0u)
		{
			count = USBUART_1_GetAll(ibuffer);
			if(count != 0)
			{
				for(i = 0;i < count;i++)
				{
					if(('0' <= ibuffer[i]) && ('9' >= ibuffer[i]))
					{
						pwm = ibuffer[i] - '0';
						if(pwm == 0)
						{
							pwm = 100;
						}
					}
				}
			} 
		}
	}
}

/* [] END OF FILE */
