
#include <project.h>

uint8 LIN_Master_id_send(uint8 id);
uint8 LIN_Master_GetArray(uint8 id,uint8 length,uint8* buffer);
void LIN_Master_PutArray(uint8 id,uint8 length,uint8* const buffer);

int main()
{
	uint8 Txbuffer[10] = {"ABCDEFG"};
	uint8 Rxbuffer[10] = {0};
	int i;
	uint8 err[3] = {0};
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    CyGlobalIntEnable;  /* Uncomment this line to enable global interrupts. */
    UART_1_Start();
	//UART_1_EnableTxInt();
	//UART_1_EnableRxInt();
	
	for(;;)
	{
		// ヘッダー送信
		LIN_Master_PutArray(2,8,Txbuffer);
		
		//CyDelayUs(20);
		/*
		do{
		err[1] = LIN_Master_GetArray(1,1,err);
		}while(err[0] != 0);
		*/
		err[1] = LIN_Master_GetArray(0,8,Rxbuffer);
    }
}

uint8 LIN_Master_id_send(uint8 id)
{
	uint8 p0 = 0;
	uint8 p1 = 0;
	p0 = (id&0x01)^((id >> 1)&0x01)^((id >> 2)&0x01)^((id >> 4)&0x01);
	p1 = ~(((id >> 1)&0x01)^((id >> 3)&0x01)^((id >> 4)&0x01)^((id >> 5)&0x01));
	id = (id&0x3f)|((p0 << 6)&0x40)|((p1 << 7)&0x80);
	UART_1_SendBreak(UART_1_SEND_WAIT_REINIT);
	UART_1_ClearTxBuffer();
	UART_1_ClearRxBuffer();
	UART_1_PutChar(0x55);
	UART_1_PutChar(id);
	while(!(UART_1_ReadTxStatus() & UART_1_TX_STS_COMPLETE));
	return id;
}

uint8 LIN_Master_GetArray(uint8 id,uint8 length,uint8* buffer)
{
	uint8 i;
	uint32 t;
	uint16 rxdata;
	uint16 sum = LIN_Master_id_send(id);
	UART_1_ClearRxBuffer();
	UART_1_ClearTxBuffer();
	for(i = 0;i < length;i++)
	{
		t = 0;
		while(!(UART_1_ReadRxStatus() & UART_1_RX_STS_FIFO_NOTEMPTY))
		{
			if(t < 1000)
			{
				t++;
			}
			else
			{
				t = 0;
				return 1;
			}
			CyDelayUs(1);
		}
		rxdata = UART_1_GetByte();
		if(!(rxdata & 0x8000))
		{
			rxdata   &= 0xff;
			sum      += rxdata;
			buffer[i] = rxdata;
		}
		else
		{
			return 1;
		}
	}
	sum = 0xff & (~( ((sum >> 8) & 0x7) + (sum & 0xff)));
	t = 0;
	while(!(UART_1_ReadRxStatus() & UART_1_RX_STS_FIFO_NOTEMPTY))
	{
		if(t < 1000)
		{
			t++;
		}
		else
		{
			t = 0;
			return 1;
		}
		CyDelayUs(1);
	}
	if((0xff & sum) == (0xff & UART_1_GetByte()))
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

void LIN_Master_PutArray(uint8 id,uint8 length,uint8* buffer)
{
	uint8 i;
	uint32 t;
	uint16 rxdata;
	uint16 sum = LIN_Master_id_send(id);
	UART_1_ClearRxBuffer();
	UART_1_ClearTxBuffer();
	for(i = 0;i < length;i++)
	{
		sum += buffer[i];
		UART_1_PutChar(buffer[i]);
		while(!(UART_1_ReadTxStatus() & UART_1_TX_STS_COMPLETE));	
	}
	sum = 0xff & (~( ((sum >> 8) & 0x7) + (sum & 0xff)));
	UART_1_PutChar(sum);
	while(!(UART_1_ReadTxStatus() & UART_1_TX_STS_COMPLETE));
}
