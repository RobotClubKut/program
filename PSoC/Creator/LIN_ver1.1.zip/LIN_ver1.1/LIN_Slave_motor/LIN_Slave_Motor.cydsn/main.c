/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

#define ACS_SENS 0.002724783

// ALI 0 ~ 10000
#define Motor_pwm_WriteCompare_ALI(x) Motor_pwm_WriteCompare1(x)
// BLI 0 ~ 10000
#define Motor_pwm_WriteCompare_BLI(x) Motor_pwm_WriteCompare2(x)


void LIN_Slave_init();
void Motor_Front(uint16 pwm);
void Motor_Back(uint16 pwm);
void Motor_Brake();

int16 delta_d;

CY_ISR(isr_1_isr)
{
	l_bool_wr_RORI_F(1);
	//delta_d = QuadDec_1_GetCounter();
	//delta_d = 100;
	QuadDec_1_SetCounter(0);
	l_u16_wr_dRORI(delta_d);
	l_bool_wr_RORI_F(0);
}

int main()
{
	uint8 test_data[8] = {0};
	uint8 out_data[8] = {0};
	uint8 i;
    uint8 signal;
    uint8 cond = 0u;
	
	// Motor value
	uint8 vr;
	
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
	 /* Call initialization function */
	isr_1_StartEx(isr_1_isr);
	QuadDec_1_Start();
	Motor_pwm_Start();
	// adc init
	ADC_DelSig_1_Start();
	ADC_DelSig_1_StartConvert();
    // lin init
	LIN_Slave_init();
	l_bool_wr_RORI_F(0);
	
	Motor_Brake();
	Motor_Front(8000);
    for(;;)
    {
		if(ADC_DelSig_1_IsEndConversion(ADC_DelSig_1_RETURN_STATUS))
		{
			ADC_DelSig_1_GetResult16();
		}
		if(l_flg_tst_vr() == 1)
		{
			delta_d = l_u8_rd_vr();
		}
		/*
		if(l_flg_tst_SignalIn() == 1)
		{
			l_bytes_rd_SignalIn(0,8,test_data);
			for(i = 0;i < 8;i++)
			{
				out_data[i] = test_data[i];
			}
			l_bytes_wr_SignalOut(0,8,out_data);
		}
		*/
		/*
        if((ld_raw_rx_status(LIN_1_IFC_HANDLE) == LD_RECEIVE_ERROR) ||
        (ld_raw_tx_status(LIN_1_IFC_HANDLE) == LD_TRANSMIT_ERROR))
        {
            ld_init(LIN_1_IFC_HANDLE);
        }
		*/
    }
}

void LIN_Slave_init()
{
	if(0u != l_sys_init())
    {
        /* Process component initialization error here */
        CyHalt(0x00u);
    }

    /* Start LIN component */
    if(0u != l_ifc_init(LIN_1_IFC_HANDLE))
    {
        /* Process component initialization error here */
        CyHalt(0x00u);
    }

    /* Initialize Transport Layer */
    //ld_init(LIN_1_IFC_HANDLE);
}
void Motor_Front(uint16 pwm)
{
	Motor_pwm_WriteCompare_ALI(pwm);
	Motor_pwm_WriteCompare_BLI(0);
	AHI_Write(0);
	BHI_Write(1);
}
void Motor_Back(uint16 pwm)
{
	Motor_pwm_WriteCompare_ALI(0);
	Motor_pwm_WriteCompare_BLI(pwm);
	AHI_Write(1);
	BHI_Write(0);
}
void Motor_Brake()
{
	Motor_pwm_WriteCompare_ALI(10000);
	Motor_pwm_WriteCompare_BLI(10000);
	AHI_Write(0);
	BHI_Write(0);
}
/* [] END OF FILE */
