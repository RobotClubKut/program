#include <project.h>

int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
	UART_1_Start();
    for(;;)
    {
		UART_1_SendBreak(UART_1_SEND_WAIT_REINIT);
        UART_1_PutChar(0x55);
		UART_1_PutChar('A');
		UART_1_PutChar('B');
		UART_1_PutChar('\n');
		CyDelay(10);
    }
}