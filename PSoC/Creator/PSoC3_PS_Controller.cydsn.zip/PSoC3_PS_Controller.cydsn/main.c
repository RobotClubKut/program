/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>

/* PSコントローラーボタン定義 */
#define up         (PS_data[0]&0x10)==0x10
#define down       (PS_data[0]&0x40)==0x40
#define right      (PS_data[0]&0x20)==0x20
#define left       (PS_data[0]&0x80)==0x80

#define triangle   (PS_data[1]&0x10)==0x10
#define cross      (PS_data[1]&0x40)==0x40
#define circle     (PS_data[1]&0x20)==0x20
#define square     (PS_data[1]&0x80)==0x80

#define l1         (PS_data[1]&0x04)==0x04
#define r1	       (PS_data[1]&0x08)==0x08
#define l2	       (PS_data[1]&0x01)==0x01
#define r2	       (PS_data[1]&0x02)==0x02
#define l3	       (PS_data[0]&0x02)==0x02	//L3, R3はアナログスティックの押しこみボタン
#define r3	       (PS_data[0]&0x04)==0x04

#define start	   (PS_data[0]&0x08)==0x08
#define select     (PS_data[0]&0x01)==0x01

#define analog_r_x   PS_data[2]   // 左0 < 中心127 < 右255 
#define analog_r_y   PS_data[3]   // 上0 < 中心127 < 下255

#define analog_l_x   PS_data[4]   // 左0 < 中心127 < 右255 
#define analog_l_y   PS_data[5]   // 上0 < 中心127 < 下255

uint8 PS_Controller_get(uint8* SwitchRecv);
void main()
{
    uint8 PS_data[8];
    uint8 rec_data = 0u;
    uint8 t = 0;
    uint8 err;
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    CyGlobalIntEnable;  /* Uncomment this line to enable global interrupts. */
    UART_1_Start();
    UART_1_ClearRxBuffer();
    LCD_Char_1_Start();
    LCD_Char_1_ClearDisplay();
    
    for(;;)
    {
        err = PS_Controller_get(PS_data);
        //* LCDに出力 */
        LCD_Char_1_Position(0u, 0u);
        LCD_Char_1_PrintString("RX RY LX LY 0 1 ");
        LCD_Char_1_Position(1u, 0u);
        LCD_Char_1_PrintInt8(analog_r_x);
        LCD_Char_1_PrintString(" ");
        LCD_Char_1_PrintInt8(analog_r_y);
        LCD_Char_1_PrintString(" ");
        LCD_Char_1_PrintInt8(analog_l_x);
        LCD_Char_1_PrintString(" ");
        LCD_Char_1_PrintInt8(analog_l_y);
        LCD_Char_1_PrintString(" ");
        LCD_Char_1_PrintInt8(PS_data[0]);
        LCD_Char_1_PrintInt8(PS_data[1]);
        //CyDelay(1);
    }
}
uint8 PS_Controller_get(uint8* SwitchRecv)
{
    
    uint16 buff;
    uint16 udata;
    uint16 temp;
    uint8 i = 0;
    uint16 timeout_t = 0;
    UART_1_ClearRxBuffer();
    for(i = 0;i < 12;i++)
    {
        //if(i >= 8)
        //{
        //    return 1;
        //}
        timeout_t = 0;
        while(UART_1_GetRxBufferSize() <= 8)
        {
            if(timeout_t < 10000)
            {
                timeout_t++;
            }
            else
            {
                return 2;
            }
            CyDelayUs(1);
        }
        if((UART_1_ReadRxData() & 0x0F) == 0x0F)
        {
            break;
        }
    }
    for(i = 0;i < 12;i++)
    {
        timeout_t = 0;
        while(UART_1_GetRxBufferSize() <= 8)
        {
            if(timeout_t < 10000)
            {
                timeout_t++;
            }
            else
            {
                return 3;
            }
            CyDelayUs(1);
        }
        udata = UART_1_ReadRxData();
        if(!(udata & 0x08)){
            buff = udata;
            continue;
        }
        if((udata & 0x07)==(buff & 0x07)){
            temp  = buff & 0xF0;
            temp |= udata >> 4;
            SwitchRecv[udata & 0x07] = temp;
        }
        /*
        if(udata & 0x0f == 0x0f)
        {
            return 0;
        }
        */
    }
    return -1;
}
/* [] END OF FILE */

