/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>

void main()
{
	int count;
	uint8 buffer[64];

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
	CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
	
	USBUART_1_Start(0,USBUART_1_5V_OPERATION );
	
	/* Wait for Device to enumerate */
    while(!USBUART_1_GetConfiguration());
	
	USBUART_1_CDC_Init();
    
    for(;;)
    {
		 if(USBUART_1_DataIsReady() != 0u)               /* Check for input data from PC */
        {   
            count = USBUART_1_GetAll(buffer);           /* Read received data and re-enable OUT endpoint */
            if(count != 0u)
            {
                while(USBUART_1_CDCIsReady() == 0u);    /* Wait till component is ready to send more data to the PC */ 
                USBUART_1_PutData(buffer, count);       /* Send data back to PC */
            }
        }
    }
}

/* [] END OF FILE */
