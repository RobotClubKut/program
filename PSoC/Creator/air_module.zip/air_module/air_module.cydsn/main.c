/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include <stdlib.h>

//uint8 air_1,air_2,air_3,air_4,air_5,air_6;
uint8 air_data;
char buffer[32];

void LIN_Slave_init()
{
	if(0u != l_sys_init()){
		
		CyHalt(0x00);
		
	}
	
	if(0u != l_ifc_init(LIN_1_IFC_HANDLE)){
	
		CyHalt(0x00);
		
	}
}

int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    CyGlobalIntEnable;  /* Uncomment this line to enable global interrupts. */
	LIN_Slave_init();
	UART_1_Start();
	UART_1_EnableTxInt();
    for(;;)
    {
		/* Place your application code here. */
		
		/////マスターからデータ取得/////////
	//	if(l_flg_tst_air_date() == 1)
	//	{
			air_data = l_u8_rd_air_date();
	//	}
		
		/////空気１のON,OFF/////////////
		if(air_data & (1 << 7))
		{
    		air_1_Write(1);
		}
		
		else if(!(air_data & (1 << 7)))
		{
    		air_1_Write(0);
		}
		
		/////空気2のON,OFF/////////////
		if(air_data & (1 << 6))
		{
			air_2_Write(1);
		}
		
		else if(!(air_data & (1 << 6)))
		{
			air_2_Write(0);
		}
		
		/////空気3のON,OFF/////////////
		if(air_data & (1 << 5))
		{
			air_3_Write(1);
		}
		
		else if(!(air_data & (1 << 5)))
		{
			air_3_Write(0);	
		}
		
		/////空気4のON,OFF/////////////
		if(air_data & (1 << 4))
		{
			air_4_Write(1);
		}
		
		else if(!(air_data & (1 << 4)))
		{
			air_4_Write(0);	
		}
		
		/////空気4,5のON,OFF(2回路の電磁弁はH/LかL/Hで駆動できる)/////////////
		if(air_data & (1 << 3))
		{
			air_5_Write(0);
			air_6_Write(1);
		}
		
		else if(!(air_data & (1 << 3)))
		{
			air_5_Write(1);
			air_6_Write(0);
		}
		
		/////空気6,7のON,OFF(2回路の電磁弁はH/LかL/Hで駆動できる)/////////////
		if(air_data & (1 << 2))
		{
			air_7_Write(0);
			air_8_Write(1);
		}
		
    	else if(!(air_data & (1 << 2)))
		{
    		air_7_Write(1);
			air_8_Write(0);
		}
		
		/////UARTデバック用//////////
		if(UART_1_ReadTxStatus() & UART_1_TX_STS_FIFO_EMPTY)
		{
			
			sprintf(buffer,"%5d ,  %5x\n",(int)air_data,(int16)l_ifc_read_status_LIN_1());
			UART_1_PutString(buffer);
		}
	}
}


/* [] END OF FILE */
