/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>

// 7 * 13 * 17 * 42
//#define MAXPWM 64974

// 11 * 13 * 17 * 26
//#define MAXPWM 63206

// 19 * 23 * 29 * 5
#define MAXPWM 63365

CY_ISR(Clock_2_isr)
{
	static uint16 pwm_r;
	static uint16 pwm_g;
	static uint16 pwm_b;
	static bit r;
	static bit g;
	static bit b;
	static uint8 inc_r = 19;
	static uint8 inc_g = 23;
	static uint8 inc_b = 29;
	static uint8 count;
	
	if (pwm_r == 0)
		r = 1;
	else if (pwm_r >= MAXPWM)
		r = 0;
	
	if (pwm_g == 0)
		g = 1;
	else if (pwm_g >= MAXPWM)
		g = 0;
	
	if (pwm_b == 0)
		b = 1;
	else if (pwm_b >= MAXPWM)
		b = 0;
	
	r ? (pwm_r += inc_r) : (pwm_r -= inc_r);
	g ? (pwm_g += inc_g) : (pwm_g -= inc_g);
	b ? (pwm_b += inc_b) : (pwm_b -= inc_b);
	
	PWM_1_WriteCompare(pwm_r);
	PWM_2_WriteCompare(pwm_g);
	PWM_3_WriteCompare(pwm_b);
	
	if ((pwm_r == 0) && (pwm_g == 0) && (pwm_b == 0))
	{
		switch (count)
		{
			case 0 :
				inc_r = 19;
				inc_g = 23;
				inc_b = 29;
				break;
				
			case 1 :
				inc_r = 23;
				inc_g = 29;
				inc_b = 19;
				break;
				
			case 2 :
				inc_r = 29;
				inc_g = 19;
				inc_b = 23;
				break;
			
			case 3 :
				inc_r = 19;
				inc_g = 29;
				inc_b = 23;
				break;
				
			case 4 :
				inc_r = 29;
				inc_g = 23;
				inc_b = 19;
				break;
			
			case 5 :
				inc_r = 23;
				inc_g = 19;
				inc_b = 29;
				break;
			
			default :
				count = 0;
				inc_r = 19;
				inc_g = 23;
				inc_b = 29;
				break;
		}
		
		(count >= 5) ? (count = 0) : (count++);
	}
}

void main()
{
	/* Place your initialization/startup code here (e.g. MyInst_Start()) */

	uint8 pwm = 0;
	
	Clock_1_Start();
	Clock_2_Start();
	PWM_1_Start();
	PWM_2_Start();
	PWM_3_Start();
	isr_1_StartEx(Clock_2_isr);
	
	QuadDec_1_Start();
	
	CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
	
	for(;;)
	{
		/* Place your application code here. */
		/*
		uint8 tmp = pwm;
		*((int8 *)&pwm) = QuadDec_1_GetCounter();
		if (tmp != pwm)
		{
			PWM_1_WriteCompare((uint16)pwm << 8);
			PWM_2_WriteCompare((uint16)pwm << 8);
			PWM_3_WriteCompare((uint16)pwm << 8);
		}
		*/
	}
}

/* [] END OF FILE */
