/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>

#define PWM_MAX 0xff

CYBIT r, g, b, m;

CY_ISR_PROTO(RGB_isr);
CY_ISR_PROTO(BLDC_isr);

int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
	
	Clock_RGB_Start();
	timer_clock_Start();
	PWM_RG_Start();
	PWM_B_Start();
	Timer_RGB_Start();
	isr_RGB_StartEx(RGB_isr);
	isr_RGB_Enable();
	
	QuadDec_1_Start();
	
	timer_clock_1_Start();
	Timer_bldc_Start();
	isr_bldc_StartEx(BLDC_isr);
	isr_bldc_Enable();
	
    CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
    for(;;)
    {
        /* Place your application code here. */
		
		int8 rori = QuadDec_1_GetCounter();
		if (rori != 0)
		{
			static int16 rgb_speed;
			uint8 timer;
			QuadDec_1_SetCounter(0);
			rgb_speed += rori;
			
			if (rgb_speed > 0xff)
				rgb_speed = 0xff;
			else if (rgb_speed < 0)
				rgb_speed = 0;
			
			timer = rgb_speed;
			Timer_RGB_WritePeriod(++timer);
		}
		
		if (r)
		{
			static uint8 pwm;
			static CYBIT t;
			if (pwm == 0)
				t = 1;
			else if (pwm == PWM_MAX)
				t = 0;
			t ? pwm++ : pwm--;
			PWM_RG_WriteCompare1(pwm);
			r = 0;
		}
		if (g)
		{
			static uint8 pwm;
			static CYBIT t;
			if (pwm == 0)
				t = 1;
			else if (pwm == PWM_MAX)
				t = 0;
			t ? pwm++ : pwm--;
			PWM_RG_WriteCompare2(pwm);
			g = 0;
		}
		if (b)
		{
			static uint8 pwm;
			static CYBIT t;
			if (pwm == 0)
				t = 1;
			else if (pwm == PWM_MAX)
				t = 0;
			t ? pwm++ : pwm--;
			PWM_B_WriteCompare(pwm);
			b = 0;
		}
		
		if (m)
		{
			const uint8 bldc[] = {0x1, 0x3, 0x2, 0x6, 0x4, 0x5};
			static uint8 i;
			Control_Reg_1_Write(bldc[i]);
			if (++i >= 6)
				i = 0;
			m = 0;
		}
		
    }
}

CY_ISR(BLDC_isr)
{
	m = 1;
}

CY_ISR(RGB_isr)
{
	static data uint8 count_r, count_g, count_b;
	if (++count_r >= 19)
	{
		r = 1;
		count_r = 0;
	}
	if (++count_g >= 23)
	{
		g = 1;
		count_g = 0;
	}
	if (++count_b >= 29)
	{
		b = 1;
		count_b = 0;
	}
}

/* [] END OF FILE */
