/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <project.h>
#include <stdio.h>
#include <string.h>

#define VL 30
const uint8 pwm_sin[VL] =
{
	0,
	27,
	53,
	79,
	104,
	128,
	150,
	171,
	190,
	206,
	221,
	233,
	243,
	249,
	254,
	255,
	254,
	249,
	243,
	233,
	221,
	206,
	190,
	171,
	150,
	128,
	104,
	79,
	53,
	27
};

uint8 psin[500] = {0};

volatile uint8 f_pwm;

CY_ISR(PWM_isr)
{
	f_pwm = 1;
}

uint8 bldc_rotate(uint8);
uint8 bldc_init(void);

int main()
{	
    CyGlobalIntEnable;
	
	QuadDec_1_Start();
	PWM_A_Start();
	PWM_B_Start();
	PWM_C_Start();
	Timer_1_Start();
	isr_PWM_StartEx(PWM_isr);
	isr_PWM_Enable();
	//bldc_init();
	//isr_PWM_Disable();
	
	while (1)
	{
		static uint8 pA;
		if (f_pwm)
		{
			f_pwm = 0;	
			pA = bldc_rotate(pA);
		}
	}
	
	while (1)
	{
		static int16 countold;
		int16 count = QuadDec_1_GetCounter();
		if (count != countold)
		{
			countold = count;
			if (count < 0)
				count += 500;
			(count < 375) ? (count += 125) : (count -= 375); 
			bldc_rotate(psin[count]);
		}
	}
	
	/*
	USBUART_1_Start(0, USBUART_1_5V_OPERATION);
	while(!USBUART_1_GetConfiguration());
	USBUART_1_CDC_Init();
	USBUART_1_PutData((uint8 *)"USB OK\n", 8);
	*/
}

uint8 bldc_init(void)
{
	uint8 i = 0;
	uint8 pA = 0;
	//rori init
	while (i < 4)
	{
		if (f_pwm)
		{
			f_pwm = 0;
			if (QuadDec_1_GetCounter() == 0)
				i++;		
			pA = bldc_rotate(pA);
		}
	}
	i = 0;
	while (i < 4)
	{
		if (f_pwm)
		{
			int16 count = QuadDec_1_GetCounter();
			if (count < 0)
				count += 500;
			f_pwm = 0;
			if (count == 0)
				i++;		
			psin[count] = pA;
			pA = bldc_rotate(pA);
		}
	}
	return 0;
}


uint8 bldc_rotate(uint8 pA)
{
	uint8 pB = ((pA < 40) ? (pA + 20) : (pA - 40));
	uint8 pC = ((pB < 40) ? (pB + 20) : (pB - 40));
	
	// A
	if (pA < VL)
	{
		PWM_A_WriteCompare1(0);	//AL
		PWM_A_WriteCompare2(pwm_sin[pA]);	//AH
	}
	else
	{
		PWM_A_WriteCompare1(pwm_sin[pA]);
		PWM_A_WriteCompare2(0);
	}
	
	// B
	if (pB < VL)
	{
		PWM_B_WriteCompare1(0);	//BL
		PWM_B_WriteCompare2(pwm_sin[pB]);	//BH
	}
	else
	{
		PWM_B_WriteCompare1(pwm_sin[pB]);
		PWM_B_WriteCompare2(0);
	}
	
	// C
	if (pC < VL)
	{
		PWM_C_WriteCompare1(0);	//CL
		PWM_C_WriteCompare2(pwm_sin[pC]);	//CH
	}
	else
	{
		PWM_C_WriteCompare1(pwm_sin[pC]);
		PWM_C_WriteCompare2(0);
	}
	
	return ((pA >= (VL * 2)) ? (0) : (pA + 1));
}

/* [] END OF FILE */
