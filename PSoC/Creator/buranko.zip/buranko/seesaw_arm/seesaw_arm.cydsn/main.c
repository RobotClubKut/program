/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include <stdlib.h>

int timer_flag = 0; 
int	pulse_count = 0;
uint8 buffer[32];
volatile int set_flag = 5;
int target = 0;
/////モータ駆動//////////////////

void motor_up_down(int motor_up_value,int motor_down_value)
{

	PWM_1_WriteCompare1(motor_down_value);
	PWM_1_WriteCompare2(motor_up_value);
	
}

void motor_front_back(int motor_front_value,int motor_back_value)
{

	PWM_2_WriteCompare1(motor_front_value);
	PWM_2_WriteCompare2(motor_back_value);
	
}

void front_reset()
{
	while(UP_LIMIT_Read() == 1)
	{
		motor_front_back(0,0);
		
		CyDelay(700);
		
		pulse_count = -2500;
		
		motor_front_back(30,0);
		
		CyDelay(700);
		
		motor_front_back(0,0);
	}
		
}

void back_reset()
{
	while(DOWN_LIMIT_Read() == 1)
	{
		motor_front_back(0,0);
		
		CyDelay(700);
		
		pulse_count = 500;
		
		motor_front_back(0,30);
		
		CyDelay(700);
		
		motor_front_back(0,0);
		
			
	}	
}

/////LIN/////////////////////

void LIN_Slave_init()
{
	if(0u != l_sys_init()){
		
		CyHalt(0x00);
		
	}
	
	if(0u != l_ifc_init(LIN_1_IFC_HANDLE)){
	
		CyHalt(0x00);
		
	}
}


/////ロリコン//////////////////////

CY_ISR(motor_isr)
{
	pulse_count += 	QuadDec_1_GetCounter();
	sprintf(buffer,"%6d , %6d , %6d\n",(int)pulse_count,(int)QuadDec_1_GetCounter(),(int)target);
	UART_1_PutString(buffer);
	QuadDec_1_SetCounter(0);
}

int main()
{
	
	int i=0;
	uint8 motor_status = 0;
	uint8 motor_target_flag =0;

	

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
	
	CyGlobalIntEnable; 
	PWM_1_Start();
	PWM_2_Start();
	QuadDec_1_Start();
	LIN_Slave_init();
	isr_1_StartEx(motor_isr);
	UART_1_Start();
	UART_1_EnableTxInt();
  
  	
	/////set///////////////////////////
	
	if(set_flag == 5){
			
		motor_front_back(30,0);
		
		while(DOWN_LIMIT_Read() == 0);
		
		motor_front_back(0,0);
		
		CyDelay(1000);
		
		motor_front_back(0,30);
		
		CyDelay(2000);
		
		motor_front_back(0,0);
		
		pulse_count = 0;
		
		set_flag = 0;
		
	}

	
	/////main_arm//////////////////////backが正の方向
	
	for(;;)	{
		
		/////マスターからモータ状態データ取得/////////////////
		if((!(l_flg_tst_motor_status() == 0)) && (motor_target_flag == 0))
		{
			
			motor_status = l_u8_rd_motor_status() & 0x3f;
			target = motor_status * 100 * (-1);
			motor_target_flag =1;
		
		}
		
		
		if(pulse_count == target)
		{
			motor_front_back(255,255);
			CyDelay(1000);
			motor_target_flag =0;
		}
		
		else if((pulse_count > target) && ((target - pulse_count) < -350 ))
		{
			motor_front_back(0,250);
		}
		
		else if((pulse_count < target) && ((pulse_count - target) < -350 ))
		{
			motor_front_back(250,0);
		}
		
		else if(pulse_count > target)
		{
			motor_front_back(0,20);
		}
		
		else if(pulse_count < target)
		{
			motor_front_back(20,0);
		}
		
		front_reset();
		back_reset();
		
    }
}


/* [] END OF FILE */
