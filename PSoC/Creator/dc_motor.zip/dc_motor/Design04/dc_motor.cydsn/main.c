/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include <stdlib.h>

char buffer[32];
int16 count1,count2,det_count;

void roricon(void){
	
	count1 = QuadDec_1_GetCounter();
	sprintf(buffer,"data = %d \n",count1);
	if(USBUART_1_CDCIsReady() == 0u)
	USBUART_1_PutString(buffer);
//	QuadDec_1_SetCounter(0);
	
}
void motor_control(uint8 x,uint8 y){
	
	PWM_A_WriteCompare1(x);
	PWM_A_WriteCompare2(y);	
}

int main()
{

	uint8 A_HL=200,B_HL=127;
	uint16 i_data;
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
	CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
	PWM_A_Start();
	QuadDec_1_Start();
	ADC_DelSig_1_Start();
	USBUART_1_Start(0,USBUART_1_5V_OPERATION );
	while(!USBUART_1_GetConfiguration());
	USBUART_1_CDC_Init();
	
    for(;;)
    {
		//motor_control(A_HL,B_HL);
		roricon();
//		ADC_DelSig_1_StartConvert();
//		while(ADC_DelSig_1_IsEndConversion(ADC_DelSig_1_WAIT_FOR_RESULT) == 0);
//		i_data = ADC_DelSig_1_GetResult16();
    }
}

/* [] END OF FILE */
