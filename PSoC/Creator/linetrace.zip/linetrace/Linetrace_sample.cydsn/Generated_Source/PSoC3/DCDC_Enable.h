/*******************************************************************************
* File Name: DCDC_Enable.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DCDC_Enable_H) /* Pins DCDC_Enable_H */
#define CY_PINS_DCDC_Enable_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "DCDC_Enable_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    DCDC_Enable_Write(uint8 value) ;
void    DCDC_Enable_SetDriveMode(uint8 mode) ;
uint8   DCDC_Enable_ReadDataReg(void) ;
uint8   DCDC_Enable_Read(void) ;
uint8   DCDC_Enable_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define DCDC_Enable_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define DCDC_Enable_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define DCDC_Enable_DM_RES_UP          PIN_DM_RES_UP
#define DCDC_Enable_DM_RES_DWN         PIN_DM_RES_DWN
#define DCDC_Enable_DM_OD_LO           PIN_DM_OD_LO
#define DCDC_Enable_DM_OD_HI           PIN_DM_OD_HI
#define DCDC_Enable_DM_STRONG          PIN_DM_STRONG
#define DCDC_Enable_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define DCDC_Enable_MASK               DCDC_Enable__MASK
#define DCDC_Enable_SHIFT              DCDC_Enable__SHIFT
#define DCDC_Enable_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define DCDC_Enable_PS                     (* (reg8 *) DCDC_Enable__PS)
/* Data Register */
#define DCDC_Enable_DR                     (* (reg8 *) DCDC_Enable__DR)
/* Port Number */
#define DCDC_Enable_PRT_NUM                (* (reg8 *) DCDC_Enable__PRT) 
/* Connect to Analog Globals */                                                  
#define DCDC_Enable_AG                     (* (reg8 *) DCDC_Enable__AG)                       
/* Analog MUX bux enable */
#define DCDC_Enable_AMUX                   (* (reg8 *) DCDC_Enable__AMUX) 
/* Bidirectional Enable */                                                        
#define DCDC_Enable_BIE                    (* (reg8 *) DCDC_Enable__BIE)
/* Bit-mask for Aliased Register Access */
#define DCDC_Enable_BIT_MASK               (* (reg8 *) DCDC_Enable__BIT_MASK)
/* Bypass Enable */
#define DCDC_Enable_BYP                    (* (reg8 *) DCDC_Enable__BYP)
/* Port wide control signals */                                                   
#define DCDC_Enable_CTL                    (* (reg8 *) DCDC_Enable__CTL)
/* Drive Modes */
#define DCDC_Enable_DM0                    (* (reg8 *) DCDC_Enable__DM0) 
#define DCDC_Enable_DM1                    (* (reg8 *) DCDC_Enable__DM1)
#define DCDC_Enable_DM2                    (* (reg8 *) DCDC_Enable__DM2) 
/* Input Buffer Disable Override */
#define DCDC_Enable_INP_DIS                (* (reg8 *) DCDC_Enable__INP_DIS)
/* LCD Common or Segment Drive */
#define DCDC_Enable_LCD_COM_SEG            (* (reg8 *) DCDC_Enable__LCD_COM_SEG)
/* Enable Segment LCD */
#define DCDC_Enable_LCD_EN                 (* (reg8 *) DCDC_Enable__LCD_EN)
/* Slew Rate Control */
#define DCDC_Enable_SLW                    (* (reg8 *) DCDC_Enable__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define DCDC_Enable_PRTDSI__CAPS_SEL       (* (reg8 *) DCDC_Enable__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define DCDC_Enable_PRTDSI__DBL_SYNC_IN    (* (reg8 *) DCDC_Enable__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define DCDC_Enable_PRTDSI__OE_SEL0        (* (reg8 *) DCDC_Enable__PRTDSI__OE_SEL0) 
#define DCDC_Enable_PRTDSI__OE_SEL1        (* (reg8 *) DCDC_Enable__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define DCDC_Enable_PRTDSI__OUT_SEL0       (* (reg8 *) DCDC_Enable__PRTDSI__OUT_SEL0) 
#define DCDC_Enable_PRTDSI__OUT_SEL1       (* (reg8 *) DCDC_Enable__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define DCDC_Enable_PRTDSI__SYNC_OUT       (* (reg8 *) DCDC_Enable__PRTDSI__SYNC_OUT) 


#if defined(DCDC_Enable__INTSTAT)  /* Interrupt Registers */

    #define DCDC_Enable_INTSTAT                (* (reg8 *) DCDC_Enable__INTSTAT)
    #define DCDC_Enable_SNAP                   (* (reg8 *) DCDC_Enable__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins DCDC_Enable_H */


/* [] END OF FILE */
