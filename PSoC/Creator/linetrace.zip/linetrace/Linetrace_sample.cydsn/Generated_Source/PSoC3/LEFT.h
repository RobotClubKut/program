/*******************************************************************************
* File Name: LEFT.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LEFT_H) /* Pins LEFT_H */
#define CY_PINS_LEFT_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "LEFT_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    LEFT_Write(uint8 value) ;
void    LEFT_SetDriveMode(uint8 mode) ;
uint8   LEFT_ReadDataReg(void) ;
uint8   LEFT_Read(void) ;
uint8   LEFT_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define LEFT_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define LEFT_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define LEFT_DM_RES_UP          PIN_DM_RES_UP
#define LEFT_DM_RES_DWN         PIN_DM_RES_DWN
#define LEFT_DM_OD_LO           PIN_DM_OD_LO
#define LEFT_DM_OD_HI           PIN_DM_OD_HI
#define LEFT_DM_STRONG          PIN_DM_STRONG
#define LEFT_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define LEFT_MASK               LEFT__MASK
#define LEFT_SHIFT              LEFT__SHIFT
#define LEFT_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define LEFT_PS                     (* (reg8 *) LEFT__PS)
/* Data Register */
#define LEFT_DR                     (* (reg8 *) LEFT__DR)
/* Port Number */
#define LEFT_PRT_NUM                (* (reg8 *) LEFT__PRT) 
/* Connect to Analog Globals */                                                  
#define LEFT_AG                     (* (reg8 *) LEFT__AG)                       
/* Analog MUX bux enable */
#define LEFT_AMUX                   (* (reg8 *) LEFT__AMUX) 
/* Bidirectional Enable */                                                        
#define LEFT_BIE                    (* (reg8 *) LEFT__BIE)
/* Bit-mask for Aliased Register Access */
#define LEFT_BIT_MASK               (* (reg8 *) LEFT__BIT_MASK)
/* Bypass Enable */
#define LEFT_BYP                    (* (reg8 *) LEFT__BYP)
/* Port wide control signals */                                                   
#define LEFT_CTL                    (* (reg8 *) LEFT__CTL)
/* Drive Modes */
#define LEFT_DM0                    (* (reg8 *) LEFT__DM0) 
#define LEFT_DM1                    (* (reg8 *) LEFT__DM1)
#define LEFT_DM2                    (* (reg8 *) LEFT__DM2) 
/* Input Buffer Disable Override */
#define LEFT_INP_DIS                (* (reg8 *) LEFT__INP_DIS)
/* LCD Common or Segment Drive */
#define LEFT_LCD_COM_SEG            (* (reg8 *) LEFT__LCD_COM_SEG)
/* Enable Segment LCD */
#define LEFT_LCD_EN                 (* (reg8 *) LEFT__LCD_EN)
/* Slew Rate Control */
#define LEFT_SLW                    (* (reg8 *) LEFT__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define LEFT_PRTDSI__CAPS_SEL       (* (reg8 *) LEFT__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define LEFT_PRTDSI__DBL_SYNC_IN    (* (reg8 *) LEFT__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define LEFT_PRTDSI__OE_SEL0        (* (reg8 *) LEFT__PRTDSI__OE_SEL0) 
#define LEFT_PRTDSI__OE_SEL1        (* (reg8 *) LEFT__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define LEFT_PRTDSI__OUT_SEL0       (* (reg8 *) LEFT__PRTDSI__OUT_SEL0) 
#define LEFT_PRTDSI__OUT_SEL1       (* (reg8 *) LEFT__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define LEFT_PRTDSI__SYNC_OUT       (* (reg8 *) LEFT__PRTDSI__SYNC_OUT) 


#if defined(LEFT__INTSTAT)  /* Interrupt Registers */

    #define LEFT_INTSTAT                (* (reg8 *) LEFT__INTSTAT)
    #define LEFT_SNAP                   (* (reg8 *) LEFT__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins LEFT_H */


/* [] END OF FILE */
