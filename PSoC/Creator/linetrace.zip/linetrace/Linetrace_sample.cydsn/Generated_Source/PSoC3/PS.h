/*******************************************************************************
* File Name: PS.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PS_H) /* Pins PS_H */
#define CY_PINS_PS_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "PS_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    PS_Write(uint8 value) ;
void    PS_SetDriveMode(uint8 mode) ;
uint8   PS_ReadDataReg(void) ;
uint8   PS_Read(void) ;
uint8   PS_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define PS_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define PS_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define PS_DM_RES_UP          PIN_DM_RES_UP
#define PS_DM_RES_DWN         PIN_DM_RES_DWN
#define PS_DM_OD_LO           PIN_DM_OD_LO
#define PS_DM_OD_HI           PIN_DM_OD_HI
#define PS_DM_STRONG          PIN_DM_STRONG
#define PS_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define PS_MASK               PS__MASK
#define PS_SHIFT              PS__SHIFT
#define PS_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define PS_PS                     (* (reg8 *) PS__PS)
/* Data Register */
#define PS_DR                     (* (reg8 *) PS__DR)
/* Port Number */
#define PS_PRT_NUM                (* (reg8 *) PS__PRT) 
/* Connect to Analog Globals */                                                  
#define PS_AG                     (* (reg8 *) PS__AG)                       
/* Analog MUX bux enable */
#define PS_AMUX                   (* (reg8 *) PS__AMUX) 
/* Bidirectional Enable */                                                        
#define PS_BIE                    (* (reg8 *) PS__BIE)
/* Bit-mask for Aliased Register Access */
#define PS_BIT_MASK               (* (reg8 *) PS__BIT_MASK)
/* Bypass Enable */
#define PS_BYP                    (* (reg8 *) PS__BYP)
/* Port wide control signals */                                                   
#define PS_CTL                    (* (reg8 *) PS__CTL)
/* Drive Modes */
#define PS_DM0                    (* (reg8 *) PS__DM0) 
#define PS_DM1                    (* (reg8 *) PS__DM1)
#define PS_DM2                    (* (reg8 *) PS__DM2) 
/* Input Buffer Disable Override */
#define PS_INP_DIS                (* (reg8 *) PS__INP_DIS)
/* LCD Common or Segment Drive */
#define PS_LCD_COM_SEG            (* (reg8 *) PS__LCD_COM_SEG)
/* Enable Segment LCD */
#define PS_LCD_EN                 (* (reg8 *) PS__LCD_EN)
/* Slew Rate Control */
#define PS_SLW                    (* (reg8 *) PS__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define PS_PRTDSI__CAPS_SEL       (* (reg8 *) PS__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define PS_PRTDSI__DBL_SYNC_IN    (* (reg8 *) PS__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define PS_PRTDSI__OE_SEL0        (* (reg8 *) PS__PRTDSI__OE_SEL0) 
#define PS_PRTDSI__OE_SEL1        (* (reg8 *) PS__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define PS_PRTDSI__OUT_SEL0       (* (reg8 *) PS__PRTDSI__OUT_SEL0) 
#define PS_PRTDSI__OUT_SEL1       (* (reg8 *) PS__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define PS_PRTDSI__SYNC_OUT       (* (reg8 *) PS__PRTDSI__SYNC_OUT) 


#if defined(PS__INTSTAT)  /* Interrupt Registers */

    #define PS_INTSTAT                (* (reg8 *) PS__INTSTAT)
    #define PS_SNAP                   (* (reg8 *) PS__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins PS_H */


/* [] END OF FILE */
