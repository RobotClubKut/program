/*******************************************************************************
* File Name: PWM_L2.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PWM_L2_H) /* Pins PWM_L2_H */
#define CY_PINS_PWM_L2_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "PWM_L2_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    PWM_L2_Write(uint8 value) ;
void    PWM_L2_SetDriveMode(uint8 mode) ;
uint8   PWM_L2_ReadDataReg(void) ;
uint8   PWM_L2_Read(void) ;
uint8   PWM_L2_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define PWM_L2_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define PWM_L2_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define PWM_L2_DM_RES_UP          PIN_DM_RES_UP
#define PWM_L2_DM_RES_DWN         PIN_DM_RES_DWN
#define PWM_L2_DM_OD_LO           PIN_DM_OD_LO
#define PWM_L2_DM_OD_HI           PIN_DM_OD_HI
#define PWM_L2_DM_STRONG          PIN_DM_STRONG
#define PWM_L2_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define PWM_L2_MASK               PWM_L2__MASK
#define PWM_L2_SHIFT              PWM_L2__SHIFT
#define PWM_L2_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define PWM_L2_PS                     (* (reg8 *) PWM_L2__PS)
/* Data Register */
#define PWM_L2_DR                     (* (reg8 *) PWM_L2__DR)
/* Port Number */
#define PWM_L2_PRT_NUM                (* (reg8 *) PWM_L2__PRT) 
/* Connect to Analog Globals */                                                  
#define PWM_L2_AG                     (* (reg8 *) PWM_L2__AG)                       
/* Analog MUX bux enable */
#define PWM_L2_AMUX                   (* (reg8 *) PWM_L2__AMUX) 
/* Bidirectional Enable */                                                        
#define PWM_L2_BIE                    (* (reg8 *) PWM_L2__BIE)
/* Bit-mask for Aliased Register Access */
#define PWM_L2_BIT_MASK               (* (reg8 *) PWM_L2__BIT_MASK)
/* Bypass Enable */
#define PWM_L2_BYP                    (* (reg8 *) PWM_L2__BYP)
/* Port wide control signals */                                                   
#define PWM_L2_CTL                    (* (reg8 *) PWM_L2__CTL)
/* Drive Modes */
#define PWM_L2_DM0                    (* (reg8 *) PWM_L2__DM0) 
#define PWM_L2_DM1                    (* (reg8 *) PWM_L2__DM1)
#define PWM_L2_DM2                    (* (reg8 *) PWM_L2__DM2) 
/* Input Buffer Disable Override */
#define PWM_L2_INP_DIS                (* (reg8 *) PWM_L2__INP_DIS)
/* LCD Common or Segment Drive */
#define PWM_L2_LCD_COM_SEG            (* (reg8 *) PWM_L2__LCD_COM_SEG)
/* Enable Segment LCD */
#define PWM_L2_LCD_EN                 (* (reg8 *) PWM_L2__LCD_EN)
/* Slew Rate Control */
#define PWM_L2_SLW                    (* (reg8 *) PWM_L2__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define PWM_L2_PRTDSI__CAPS_SEL       (* (reg8 *) PWM_L2__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define PWM_L2_PRTDSI__DBL_SYNC_IN    (* (reg8 *) PWM_L2__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define PWM_L2_PRTDSI__OE_SEL0        (* (reg8 *) PWM_L2__PRTDSI__OE_SEL0) 
#define PWM_L2_PRTDSI__OE_SEL1        (* (reg8 *) PWM_L2__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define PWM_L2_PRTDSI__OUT_SEL0       (* (reg8 *) PWM_L2__PRTDSI__OUT_SEL0) 
#define PWM_L2_PRTDSI__OUT_SEL1       (* (reg8 *) PWM_L2__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define PWM_L2_PRTDSI__SYNC_OUT       (* (reg8 *) PWM_L2__PRTDSI__SYNC_OUT) 


#if defined(PWM_L2__INTSTAT)  /* Interrupt Registers */

    #define PWM_L2_INTSTAT                (* (reg8 *) PWM_L2__INTSTAT)
    #define PWM_L2_SNAP                   (* (reg8 *) PWM_L2__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins PWM_L2_H */


/* [] END OF FILE */
