/*******************************************************************************
* File Name: kyori1.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_kyori1_H) /* Pins kyori1_H */
#define CY_PINS_kyori1_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "kyori1_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    kyori1_Write(uint8 value) ;
void    kyori1_SetDriveMode(uint8 mode) ;
uint8   kyori1_ReadDataReg(void) ;
uint8   kyori1_Read(void) ;
uint8   kyori1_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define kyori1_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define kyori1_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define kyori1_DM_RES_UP          PIN_DM_RES_UP
#define kyori1_DM_RES_DWN         PIN_DM_RES_DWN
#define kyori1_DM_OD_LO           PIN_DM_OD_LO
#define kyori1_DM_OD_HI           PIN_DM_OD_HI
#define kyori1_DM_STRONG          PIN_DM_STRONG
#define kyori1_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define kyori1_MASK               kyori1__MASK
#define kyori1_SHIFT              kyori1__SHIFT
#define kyori1_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define kyori1_PS                     (* (reg8 *) kyori1__PS)
/* Data Register */
#define kyori1_DR                     (* (reg8 *) kyori1__DR)
/* Port Number */
#define kyori1_PRT_NUM                (* (reg8 *) kyori1__PRT) 
/* Connect to Analog Globals */                                                  
#define kyori1_AG                     (* (reg8 *) kyori1__AG)                       
/* Analog MUX bux enable */
#define kyori1_AMUX                   (* (reg8 *) kyori1__AMUX) 
/* Bidirectional Enable */                                                        
#define kyori1_BIE                    (* (reg8 *) kyori1__BIE)
/* Bit-mask for Aliased Register Access */
#define kyori1_BIT_MASK               (* (reg8 *) kyori1__BIT_MASK)
/* Bypass Enable */
#define kyori1_BYP                    (* (reg8 *) kyori1__BYP)
/* Port wide control signals */                                                   
#define kyori1_CTL                    (* (reg8 *) kyori1__CTL)
/* Drive Modes */
#define kyori1_DM0                    (* (reg8 *) kyori1__DM0) 
#define kyori1_DM1                    (* (reg8 *) kyori1__DM1)
#define kyori1_DM2                    (* (reg8 *) kyori1__DM2) 
/* Input Buffer Disable Override */
#define kyori1_INP_DIS                (* (reg8 *) kyori1__INP_DIS)
/* LCD Common or Segment Drive */
#define kyori1_LCD_COM_SEG            (* (reg8 *) kyori1__LCD_COM_SEG)
/* Enable Segment LCD */
#define kyori1_LCD_EN                 (* (reg8 *) kyori1__LCD_EN)
/* Slew Rate Control */
#define kyori1_SLW                    (* (reg8 *) kyori1__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define kyori1_PRTDSI__CAPS_SEL       (* (reg8 *) kyori1__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define kyori1_PRTDSI__DBL_SYNC_IN    (* (reg8 *) kyori1__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define kyori1_PRTDSI__OE_SEL0        (* (reg8 *) kyori1__PRTDSI__OE_SEL0) 
#define kyori1_PRTDSI__OE_SEL1        (* (reg8 *) kyori1__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define kyori1_PRTDSI__OUT_SEL0       (* (reg8 *) kyori1__PRTDSI__OUT_SEL0) 
#define kyori1_PRTDSI__OUT_SEL1       (* (reg8 *) kyori1__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define kyori1_PRTDSI__SYNC_OUT       (* (reg8 *) kyori1__PRTDSI__SYNC_OUT) 


#if defined(kyori1__INTSTAT)  /* Interrupt Registers */

    #define kyori1_INTSTAT                (* (reg8 *) kyori1__INTSTAT)
    #define kyori1_SNAP                   (* (reg8 *) kyori1__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins kyori1_H */


/* [] END OF FILE */
