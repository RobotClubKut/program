/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

int i=0;

int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    CyGlobalIntEnable;  /* Uncomment this line to enable global interrupts. */
	MOTOR_A_Start();
	MOTOR_B_Start();
    for(;;)
    {
        /* Place your application code here. */
		MOTOR_A_WriteCompare1(i);
		MOTOR_A_WriteCompare2(0);
		MOTOR_B_WriteCompare1(i);
		MOTOR_B_WriteCompare2(0);
		CyDelay(70);
		i++;
		if(i == 255)
		{	
			while(1){
				MOTOR_A_WriteCompare1(i);
				MOTOR_A_WriteCompare2(0);
				MOTOR_B_WriteCompare1(i);
				MOTOR_B_WriteCompare2(0);
				CyDelay(70);
				i--;
				if(i == 0)
					break;
			}
		}
		
    }
}

/* [] END OF FILE */
