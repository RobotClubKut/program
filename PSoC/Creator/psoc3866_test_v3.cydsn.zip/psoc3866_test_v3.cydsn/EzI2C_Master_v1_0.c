#include <device.h>
#include "EzI2C_Master_v1_0.h"

uint8 Ezi2c_master_write_buf(uint8 addr,uint8 data_addr,uint8* wrdata,uint8 cnt)
{
    uint8 status;
    uint8 i;
    
    status = I2C_MasterSendStart(addr, I2C_1_WRITE_XFER_MODE);
    if(status == 0x00u) /* Check if transfer completed without errors */
    {
        status = I2C_MasterWriteByte(data_addr);
        if(status != I2C_1_MSTR_NO_ERROR)
        {
            I2C_MasterSendStop();
            return status;
        }
        for(i=0; i < cnt; i++)
        {
            status = I2C_MasterWriteByte(wrdata[i]);
            if(status != I2C_1_MSTR_NO_ERROR)
            {
                break;
            }
        }
    }
    I2C_MasterSendStop();
    return status;
}
uint8 Ezi2c_master_read_buf(uint8 addr,uint8 data_addr,uint8* redata,uint8 cnt)
{
    uint8 status;
    uint8 i;
    status = I2C_MasterSendStart(addr, I2C_1_WRITE_XFER_MODE);
    if(status == 0x00u) /* Check if transfer completed without errors */
    {
        status = I2C_MasterWriteByte(data_addr);
        if(status != I2C_1_MSTR_NO_ERROR)
        {
            I2C_MasterSendStop();
            return status;
        }
    }
    I2C_MasterSendStop();
    status = I2C_MasterSendStart(addr, I2C_1_READ_XFER_MODE);
    if(status == 0x00u) /* Check if transfer completed without errors */
    {
        //I2C_1_MasterReadByte(I2C_1_ACK_DATA); /* 相手がPSoC3の場合 */
        for(i=0; i < cnt; i++)
        {
            if(i < cnt )
            {
                redata[i] = I2C_MasterReadByte(I2C_1_ACK_DATA);
            }
            else
            {
                redata[i] = I2C_MasterReadByte(I2C_1_NAK_DATA);
            }
        }
    }
    I2C_MasterSendStop(); /* Send Stop */
    return status;
}