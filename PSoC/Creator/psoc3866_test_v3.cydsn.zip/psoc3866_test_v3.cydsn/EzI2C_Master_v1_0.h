
#ifndef EZI2C_MASTER_V1_0_H
#define EZI2C_MASTER_V1_0_H

#include <device.h>

//コンポーネント番号展開マクロ
#define I2C_MasterSendStart(num) I2C_##num##_MasterSendStart

#define I2C_MasterWriteByte(num) I2C_##num##_MasterWriteByte

#define I2C_MasterSendStop(num) I2C_##num##_MasterSendStop

#define I2C_MasterReadByte(num) I2C_##num##_MasterReadByte

#define EZI2C_MASTER_NUM
uint8 Ezi2c_master_write_buf(uint8 addr,uint8 data_addr,uint8* wrdata,uint8 cnt);
uint8 Ezi2c_master_read_buf(uint8 addr,uint8 data_addr,uint8* redata,uint8 cnt);

#endif
