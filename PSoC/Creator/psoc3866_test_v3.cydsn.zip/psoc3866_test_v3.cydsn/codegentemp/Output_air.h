/*******************************************************************************
* File Name: Output_air.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Output_air_H) /* Pins Output_air_H */
#define CY_PINS_Output_air_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Output_air_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Output_air_Write(uint8 value) ;
void    Output_air_SetDriveMode(uint8 mode) ;
uint8   Output_air_ReadDataReg(void) ;
uint8   Output_air_Read(void) ;
uint8   Output_air_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Output_air_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Output_air_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Output_air_DM_RES_UP          PIN_DM_RES_UP
#define Output_air_DM_RES_DWN         PIN_DM_RES_DWN
#define Output_air_DM_OD_LO           PIN_DM_OD_LO
#define Output_air_DM_OD_HI           PIN_DM_OD_HI
#define Output_air_DM_STRONG          PIN_DM_STRONG
#define Output_air_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Output_air_MASK               Output_air__MASK
#define Output_air_SHIFT              Output_air__SHIFT
#define Output_air_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Output_air_PS                     (* (reg8 *) Output_air__PS)
/* Data Register */
#define Output_air_DR                     (* (reg8 *) Output_air__DR)
/* Port Number */
#define Output_air_PRT_NUM                (* (reg8 *) Output_air__PRT) 
/* Connect to Analog Globals */                                                  
#define Output_air_AG                     (* (reg8 *) Output_air__AG)                       
/* Analog MUX bux enable */
#define Output_air_AMUX                   (* (reg8 *) Output_air__AMUX) 
/* Bidirectional Enable */                                                        
#define Output_air_BIE                    (* (reg8 *) Output_air__BIE)
/* Bit-mask for Aliased Register Access */
#define Output_air_BIT_MASK               (* (reg8 *) Output_air__BIT_MASK)
/* Bypass Enable */
#define Output_air_BYP                    (* (reg8 *) Output_air__BYP)
/* Port wide control signals */                                                   
#define Output_air_CTL                    (* (reg8 *) Output_air__CTL)
/* Drive Modes */
#define Output_air_DM0                    (* (reg8 *) Output_air__DM0) 
#define Output_air_DM1                    (* (reg8 *) Output_air__DM1)
#define Output_air_DM2                    (* (reg8 *) Output_air__DM2) 
/* Input Buffer Disable Override */
#define Output_air_INP_DIS                (* (reg8 *) Output_air__INP_DIS)
/* LCD Common or Segment Drive */
#define Output_air_LCD_COM_SEG            (* (reg8 *) Output_air__LCD_COM_SEG)
/* Enable Segment LCD */
#define Output_air_LCD_EN                 (* (reg8 *) Output_air__LCD_EN)
/* Slew Rate Control */
#define Output_air_SLW                    (* (reg8 *) Output_air__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Output_air_PRTDSI__CAPS_SEL       (* (reg8 *) Output_air__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Output_air_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Output_air__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Output_air_PRTDSI__OE_SEL0        (* (reg8 *) Output_air__PRTDSI__OE_SEL0) 
#define Output_air_PRTDSI__OE_SEL1        (* (reg8 *) Output_air__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Output_air_PRTDSI__OUT_SEL0       (* (reg8 *) Output_air__PRTDSI__OUT_SEL0) 
#define Output_air_PRTDSI__OUT_SEL1       (* (reg8 *) Output_air__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Output_air_PRTDSI__SYNC_OUT       (* (reg8 *) Output_air__PRTDSI__SYNC_OUT) 


#if defined(Output_air__INTSTAT)  /* Interrupt Registers */

    #define Output_air_INTSTAT                (* (reg8 *) Output_air__INTSTAT)
    #define Output_air_SNAP                   (* (reg8 *) Output_air__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins Output_air_H */


/* [] END OF FILE */
