/*******************************************************************************
* File Name: switch_down.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_switch_down_H) /* Pins switch_down_H */
#define CY_PINS_switch_down_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "switch_down_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    switch_down_Write(uint8 value) ;
void    switch_down_SetDriveMode(uint8 mode) ;
uint8   switch_down_ReadDataReg(void) ;
uint8   switch_down_Read(void) ;
uint8   switch_down_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define switch_down_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define switch_down_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define switch_down_DM_RES_UP          PIN_DM_RES_UP
#define switch_down_DM_RES_DWN         PIN_DM_RES_DWN
#define switch_down_DM_OD_LO           PIN_DM_OD_LO
#define switch_down_DM_OD_HI           PIN_DM_OD_HI
#define switch_down_DM_STRONG          PIN_DM_STRONG
#define switch_down_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define switch_down_MASK               switch_down__MASK
#define switch_down_SHIFT              switch_down__SHIFT
#define switch_down_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define switch_down_PS                     (* (reg8 *) switch_down__PS)
/* Data Register */
#define switch_down_DR                     (* (reg8 *) switch_down__DR)
/* Port Number */
#define switch_down_PRT_NUM                (* (reg8 *) switch_down__PRT) 
/* Connect to Analog Globals */                                                  
#define switch_down_AG                     (* (reg8 *) switch_down__AG)                       
/* Analog MUX bux enable */
#define switch_down_AMUX                   (* (reg8 *) switch_down__AMUX) 
/* Bidirectional Enable */                                                        
#define switch_down_BIE                    (* (reg8 *) switch_down__BIE)
/* Bit-mask for Aliased Register Access */
#define switch_down_BIT_MASK               (* (reg8 *) switch_down__BIT_MASK)
/* Bypass Enable */
#define switch_down_BYP                    (* (reg8 *) switch_down__BYP)
/* Port wide control signals */                                                   
#define switch_down_CTL                    (* (reg8 *) switch_down__CTL)
/* Drive Modes */
#define switch_down_DM0                    (* (reg8 *) switch_down__DM0) 
#define switch_down_DM1                    (* (reg8 *) switch_down__DM1)
#define switch_down_DM2                    (* (reg8 *) switch_down__DM2) 
/* Input Buffer Disable Override */
#define switch_down_INP_DIS                (* (reg8 *) switch_down__INP_DIS)
/* LCD Common or Segment Drive */
#define switch_down_LCD_COM_SEG            (* (reg8 *) switch_down__LCD_COM_SEG)
/* Enable Segment LCD */
#define switch_down_LCD_EN                 (* (reg8 *) switch_down__LCD_EN)
/* Slew Rate Control */
#define switch_down_SLW                    (* (reg8 *) switch_down__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define switch_down_PRTDSI__CAPS_SEL       (* (reg8 *) switch_down__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define switch_down_PRTDSI__DBL_SYNC_IN    (* (reg8 *) switch_down__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define switch_down_PRTDSI__OE_SEL0        (* (reg8 *) switch_down__PRTDSI__OE_SEL0) 
#define switch_down_PRTDSI__OE_SEL1        (* (reg8 *) switch_down__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define switch_down_PRTDSI__OUT_SEL0       (* (reg8 *) switch_down__PRTDSI__OUT_SEL0) 
#define switch_down_PRTDSI__OUT_SEL1       (* (reg8 *) switch_down__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define switch_down_PRTDSI__SYNC_OUT       (* (reg8 *) switch_down__PRTDSI__SYNC_OUT) 


#if defined(switch_down__INTSTAT)  /* Interrupt Registers */

    #define switch_down_INTSTAT                (* (reg8 *) switch_down__INTSTAT)
    #define switch_down_SNAP                   (* (reg8 *) switch_down__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins switch_down_H */


/* [] END OF FILE */
