/*******************************************************************************
* File Name: switch_right.c  
* Version 1.90
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "switch_right.h"


/*******************************************************************************
* Function Name: switch_right_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None 
*  
*******************************************************************************/
void switch_right_Write(uint8 value) 
{
    uint8 staticBits = (switch_right_DR & (uint8)(~switch_right_MASK));
    switch_right_DR = staticBits | ((uint8)(value << switch_right_SHIFT) & switch_right_MASK);
}


/*******************************************************************************
* Function Name: switch_right_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to this drive mode.
*
* Return: 
*  None
*
*******************************************************************************/
void switch_right_SetDriveMode(uint8 mode) 
{
	CyPins_SetPinDriveMode(switch_right_0, mode);
}


/*******************************************************************************
* Function Name: switch_right_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro switch_right_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 switch_right_Read(void) 
{
    return (switch_right_PS & switch_right_MASK) >> switch_right_SHIFT;
}


/*******************************************************************************
* Function Name: switch_right_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 switch_right_ReadDataReg(void) 
{
    return (switch_right_DR & switch_right_MASK) >> switch_right_SHIFT;
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(switch_right_INTSTAT) 

    /*******************************************************************************
    * Function Name: switch_right_ClearInterrupt
    ********************************************************************************
    *
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 switch_right_ClearInterrupt(void) 
    {
        return (switch_right_INTSTAT & switch_right_MASK) >> switch_right_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 


/* [] END OF FILE */
