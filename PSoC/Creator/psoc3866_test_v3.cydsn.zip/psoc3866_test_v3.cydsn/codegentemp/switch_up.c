/*******************************************************************************
* File Name: switch_up.c  
* Version 1.90
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "switch_up.h"


/*******************************************************************************
* Function Name: switch_up_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None 
*  
*******************************************************************************/
void switch_up_Write(uint8 value) 
{
    uint8 staticBits = (switch_up_DR & (uint8)(~switch_up_MASK));
    switch_up_DR = staticBits | ((uint8)(value << switch_up_SHIFT) & switch_up_MASK);
}


/*******************************************************************************
* Function Name: switch_up_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to this drive mode.
*
* Return: 
*  None
*
*******************************************************************************/
void switch_up_SetDriveMode(uint8 mode) 
{
	CyPins_SetPinDriveMode(switch_up_0, mode);
}


/*******************************************************************************
* Function Name: switch_up_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro switch_up_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 switch_up_Read(void) 
{
    return (switch_up_PS & switch_up_MASK) >> switch_up_SHIFT;
}


/*******************************************************************************
* Function Name: switch_up_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 switch_up_ReadDataReg(void) 
{
    return (switch_up_DR & switch_up_MASK) >> switch_up_SHIFT;
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(switch_up_INTSTAT) 

    /*******************************************************************************
    * Function Name: switch_up_ClearInterrupt
    ********************************************************************************
    *
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 switch_up_ClearInterrupt(void) 
    {
        return (switch_up_INTSTAT & switch_up_MASK) >> switch_up_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 


/* [] END OF FILE */
