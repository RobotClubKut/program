/*******************************************************************************
* File Name: switch_up.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_switch_up_H) /* Pins switch_up_H */
#define CY_PINS_switch_up_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "switch_up_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    switch_up_Write(uint8 value) ;
void    switch_up_SetDriveMode(uint8 mode) ;
uint8   switch_up_ReadDataReg(void) ;
uint8   switch_up_Read(void) ;
uint8   switch_up_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define switch_up_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define switch_up_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define switch_up_DM_RES_UP          PIN_DM_RES_UP
#define switch_up_DM_RES_DWN         PIN_DM_RES_DWN
#define switch_up_DM_OD_LO           PIN_DM_OD_LO
#define switch_up_DM_OD_HI           PIN_DM_OD_HI
#define switch_up_DM_STRONG          PIN_DM_STRONG
#define switch_up_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define switch_up_MASK               switch_up__MASK
#define switch_up_SHIFT              switch_up__SHIFT
#define switch_up_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define switch_up_PS                     (* (reg8 *) switch_up__PS)
/* Data Register */
#define switch_up_DR                     (* (reg8 *) switch_up__DR)
/* Port Number */
#define switch_up_PRT_NUM                (* (reg8 *) switch_up__PRT) 
/* Connect to Analog Globals */                                                  
#define switch_up_AG                     (* (reg8 *) switch_up__AG)                       
/* Analog MUX bux enable */
#define switch_up_AMUX                   (* (reg8 *) switch_up__AMUX) 
/* Bidirectional Enable */                                                        
#define switch_up_BIE                    (* (reg8 *) switch_up__BIE)
/* Bit-mask for Aliased Register Access */
#define switch_up_BIT_MASK               (* (reg8 *) switch_up__BIT_MASK)
/* Bypass Enable */
#define switch_up_BYP                    (* (reg8 *) switch_up__BYP)
/* Port wide control signals */                                                   
#define switch_up_CTL                    (* (reg8 *) switch_up__CTL)
/* Drive Modes */
#define switch_up_DM0                    (* (reg8 *) switch_up__DM0) 
#define switch_up_DM1                    (* (reg8 *) switch_up__DM1)
#define switch_up_DM2                    (* (reg8 *) switch_up__DM2) 
/* Input Buffer Disable Override */
#define switch_up_INP_DIS                (* (reg8 *) switch_up__INP_DIS)
/* LCD Common or Segment Drive */
#define switch_up_LCD_COM_SEG            (* (reg8 *) switch_up__LCD_COM_SEG)
/* Enable Segment LCD */
#define switch_up_LCD_EN                 (* (reg8 *) switch_up__LCD_EN)
/* Slew Rate Control */
#define switch_up_SLW                    (* (reg8 *) switch_up__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define switch_up_PRTDSI__CAPS_SEL       (* (reg8 *) switch_up__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define switch_up_PRTDSI__DBL_SYNC_IN    (* (reg8 *) switch_up__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define switch_up_PRTDSI__OE_SEL0        (* (reg8 *) switch_up__PRTDSI__OE_SEL0) 
#define switch_up_PRTDSI__OE_SEL1        (* (reg8 *) switch_up__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define switch_up_PRTDSI__OUT_SEL0       (* (reg8 *) switch_up__PRTDSI__OUT_SEL0) 
#define switch_up_PRTDSI__OUT_SEL1       (* (reg8 *) switch_up__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define switch_up_PRTDSI__SYNC_OUT       (* (reg8 *) switch_up__PRTDSI__SYNC_OUT) 


#if defined(switch_up__INTSTAT)  /* Interrupt Registers */

    #define switch_up_INTSTAT                (* (reg8 *) switch_up__INTSTAT)
    #define switch_up_SNAP                   (* (reg8 *) switch_up__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins switch_up_H */


/* [] END OF FILE */
