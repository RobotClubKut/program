/* ========================================
 *
 * キャチロボマスター v2.0
 * 
 * PS2 →　マスタ → I2Cバス  → スレーブ（モータ）
 *         ↑   　　　　　   →　スレーブ（サーボ,空気）
 *       ロリータ
 * 
 *
 * ========================================
*/
#include <device.h>
#include <stdlib.h>
#include <math.h>

#define VERSION 1

/* PSコントローラーボタン定義 */
#define up         ((PS_data[0]&0x10)==0x10)
#define down       ((PS_data[0]&0x40)==0x40)
#define right      ((PS_data[0]&0x20)==0x20)
#define left       ((PS_data[0]&0x80)==0x80)

#define triangle   ((PS_data[1]&0x10)==0x10)
#define cross      ((PS_data[1]&0x40)==0x40)
#define circle     ((PS_data[1]&0x20)==0x20)
#define square     ((PS_data[1]&0x80)==0x80)

#define l1         ((PS_data[1]&0x04)==0x04)
#define r1	       ((PS_data[1]&0x08)==0x08)
#define l2	       ((PS_data[1]&0x01)==0x01)
#define r2	       ((PS_data[1]&0x02)==0x02)
#define l3	       ((PS_data[0]&0x02)==0x02)	//L3, R3はアナログスティックの押しこみボタン
#define r3	       ((PS_data[0]&0x04)==0x04)

#define start	   ((PS_data[0]&0x08)==0x08)
#define select     ((PS_data[0]&0x01)==0x01)

#define analog_r_x   PS_data[2]   // 左0 < 中心127 < 右255 
#define analog_r_y   PS_data[3]   // 上0 < 中心127 < 下255

#define analog_l_x   PS_data[4]   // 左0 < 中心127 < 右255 
#define analog_l_y   PS_data[5]   // 上0 < 中心127 < 下255

// I2C MailBox 用マクロ
#define I2CIO_BUSY 		0x80
#define I2CIO_DIRTY 	0x40
#define I2CIO_WRITE 	0x80
#define I2CIO_READ 		0x40
#define I2CIO_UPDATE 	0x20

#define I2CIO_OUTBOX_ADDR		0x02
#define I2CIO_INBOX_ADDR		0x0D
#define I2CIO_TRY_COMMUNICATION 0x02

// I2C スレーブアドレス
#define SLAVE_ADDR_MOTOR 30
#define SLAVE_ADDR_SERVO 12
#define SLAVE_ADDR_RORI   8

// ロリータコマンド
#define RORI_RESET 0x01

// モータ定数
#define XKbs 	4
#define XKp 	10
#define XKi 	10
#define YKbs	4
#define YKp 	10
#define YKi 	10
#define ZKbs 	4
#define ZKp 	10
#define ZKi 	10

// BOX
#define BOX_OPEN   				0
#define BOX_CLOSE  				1
// 上
#define ARM_BOX_OPEN1_OPEN		15
#define ARM_BOX_OPEN1_CLOSE		105
// 下
#define ARM_BOX_OPEN2_OPEN		100
#define ARM_BOX_OPEN2_CLOSE		10
// AIR
#define AIR_OPEN   				0
#define AIR_CLOSE  				1
#define ARM_BOX_KEEP_OPEN		0
#define ARM_BOX_KEEP_CLOSE		95
#define ARM_AIR_OPEN			1
#define ARM_AIR_CLOSE			0


// 関数プロトタイプ宣言
uint8 PS_Controller_get(uint8* SwitchRecv);
uint8 Ezi2c_master_write_buf(uint8 addr,uint8 data_addr,uint8* wrdata,uint8 cnt);
uint8 Ezi2c_master_read_buf(uint8 addr,uint8 data_addr,uint8* redata,uint8 cnt);
void reset_kikp(void);

#if (VERSION == 0) 
// モータステータス列挙型
enum MOTOR_STATUS
{
    NOT_STATUS,
    F_ACCELERATION,
    B_ACCELERATION,
    F_DECELERATION,
    B_DECELERATION,
    F_STOP,
    B_STOP
};
// モータステータス宣言
enum MOTOR_STATUS motor_x_status = NOT_STATUS;
enum MOTOR_STATUS motor_y_status = NOT_STATUS;
#endif

enum MOTOR_NUM
{
    MOTOR_X = 1,
	MOTOR_Y = 2,
	MOTOR_Z = 3
};
enum MOTOR_COMMAND
{
	MOTOR_X_BLAKE = 0x01,
	MOTOR_Y_BLAKE = 0x02,
	MOTOR_Z_BLAKE = 0x04
};

// アームデータアドレス
enum ARM_ADDR
{
	ARM_BOX_OPEN1,
	ARM_BOX_OPEN2,
	ARM_BOX_KEEP,
	ARM_ASSIST1,
	ARM_ASSIST2,
	ARM_AIR,
	ARM_MOTOR
};
// グローバル変数宣言
#if (VERSION == 0)
uint8 motor_x1 = 0;
uint8 motor_x2 = 0;
uint8 motor_y1 = 0;
uint8 motor_y2 = 0;
uint8 motor_z1 = 0;
uint8 motor_z2 = 0;
double i2c_motor_buf[6] ={0.0};
#endif

uint8 i2c_motor[6];
uint8 i2c_motor_K[9];
uint8 i2c_motor_config[2];
uint8 i2c_outbox_flag;
uint8 i2c_inbox_flag;

uint8 i2c_rori[4];

uint8 auto_up_flag;
uint8 auto_down_flag;

uint8 i2c_motor_status;

bit isr_1_flag = 0; 

CY_ISR(isr_1_isr) 
{
	#if (VERSION == 0)
    // X軸正回転
    if(((motor_x1 == 0) || (motor_x_status != F_STOP))
        && (motor_x_status != B_ACCELERATION)
        && (motor_x_status != B_DECELERATION))
    {
        if(i2c_motor[1] < motor_x2)
        {
            i2c_motor_buf[1] += (motor_x2 - i2c_motor[1]) * 0.05;
            i2c_motor[1] = (uint8)i2c_motor_buf[1];
            motor_x_status = F_ACCELERATION;
        }
        else if(i2c_motor[1] > motor_x2)
        {   
            i2c_motor_buf[1] -= 5;
            i2c_motor[1] = (i2c_motor_buf[1] < 0) ? 0 : (uint8)i2c_motor_buf[1]; 
            motor_x_status = F_DECELERATION;
        }
        else if((i2c_motor[0] == 0)
            && (i2c_motor[1] == 0))
        {
            motor_x_status = F_STOP;
        }
    }
    // X軸逆回転
    if(((motor_x2 == 0)
        || (motor_x_status != B_STOP))
        && (motor_x_status != F_ACCELERATION)
        && (motor_x_status != F_DECELERATION))
    {
        if(i2c_motor[0] < motor_x1)
        {
            i2c_motor_buf[0] += (motor_x1 - i2c_motor[0]) * 0.05;
            i2c_motor[0] = (uint8)i2c_motor_buf[0];
            motor_x_status = B_ACCELERATION;
        }
        else if(i2c_motor[0] > motor_x1)
        {   
            i2c_motor_buf[0] -= 5;
            i2c_motor[0] = (i2c_motor_buf[0] < 0) ? 0 : (uint8)i2c_motor_buf[0]; 
            motor_x_status = B_DECELERATION;
        }
        else if((i2c_motor[0] == 0)
            && (i2c_motor[1] == 0))
        {
            motor_x_status = B_STOP;
        }
    }
    // Y軸正回転
    if(((motor_y1 == 0) 
        || (motor_y_status != F_STOP))
        && (motor_y_status != B_ACCELERATION)
        && (motor_y_status != B_DECELERATION))
    {
        if(i2c_motor[3] < motor_y2)
        {
            i2c_motor_buf[3] += (motor_y2 - i2c_motor[3]) * 0.05;
            i2c_motor[3] = (uint8)i2c_motor_buf[3];
            motor_y_status = F_ACCELERATION;
        }
        else if(i2c_motor[3] > motor_y2)
        {   
            i2c_motor_buf[3] -= 4;
            i2c_motor[3] = (i2c_motor_buf[3] < 0) ? 0 : (uint8)i2c_motor_buf[3]; 
            motor_y_status = F_DECELERATION;
        }
        else if((i2c_motor[2] == 0)
            && (i2c_motor[3] == 0))
        {
            motor_y_status = F_STOP;
        }
    }
    // Y軸逆回転
    if(((motor_y2 == 0)
        || (motor_y_status != B_STOP))
        && (motor_y_status != F_ACCELERATION)
        && (motor_y_status != F_DECELERATION))
    {
        if(i2c_motor[2] < motor_y1)
        {
            i2c_motor_buf[2] += (motor_y1 - i2c_motor[2]) * 0.05;
            i2c_motor[2] = (uint8)i2c_motor_buf[2];
            motor_y_status = B_ACCELERATION;
        }
        else if(i2c_motor[2] > motor_y1)
        {   
            i2c_motor_buf[2] -= 4;
            i2c_motor[2] = (i2c_motor_buf[2] < 0) ? 0 : (uint8)i2c_motor_buf[2]; 
            motor_y_status = B_DECELERATION;
        }
        else if((i2c_motor[2] == 0)
            && (i2c_motor[3] == 0))
        {
            motor_y_status = B_STOP;
        }
    }
	#endif
	
	/************ Y軸自動制御 **************/
	
	// Y軸前進
	if(auto_up_flag && !auto_down_flag)
	{
		
	}
	// Y軸後進
	if(auto_down_flag && !auto_up_flag)
	{
		
	}
	
	isr_1_flag = 1;
}

void main()
{
	// カウント用
	int8 i = 0;
	uint8 j = 0;
	
	uint32 time = 0;
	uint32 box_time = 0;
	uint32 air_time = 0;
	
	
	// フラグ
	bit up_flag = 0;
	bit down_flag = 0;
	bit right_flag = 0;
	bit left_flag = 0;
	bit triangle_flag = 0;
	bit square_flag = 0;
	bit r1_flag = 0;
	bit l1_flag = 0;
	
	bit box_flag = 0;
	bit air_flag = 0;
	bit box_busy = 0;
	bit air_busy = 0;
	
	uint8 kikpselect_flag = 0;
	uint8 kikpselect_flag2 = 0;
	uint8 automove_flag = 0;
	uint8 automove = 0;
	
	
	// 配列データ
    uint8 PS_data[8] = {0};
    uint8 i2c_servo[7] = {0};
    uint8 i2c_air[2] = {0};
    uint8 status[10] = 0;
	
	// モーター目標速度
	uint8 motor_target_dir = 0;	// 方向
	int8 motor_target_speed[3] = {0};	// 速度
	
	// モーター現在速度
	uint8 motor_current_dir = 0;		// 方向
	int8 motor_current_speed[3] = 0;		// 速度
    
    /* 初期化（start,etc...） */
    LCD_Char_1_Start();
    I2C_1_Start();
    LCD_Char_1_ClearDisplay();
    UART_1_Start();
    UART_1_ClearRxBuffer();
    isr_1_StartEx(isr_1_isr);
	QuadDec_1_Start();
	EEPROM_1_Start();
	
	CySetTemp();
	CySetFlashEEBuffer();
	
	// グローバル割り込み許可
    CyGlobalIntEnable; 
	
	// アナログボタン押されるまで待機
    while(!analog_r_x && !analog_r_y && !analog_l_x && !analog_l_y)
    {
        PS_Controller_get(PS_data);
        LCD_Char_1_Position(0u, 0u);
        LCD_Char_1_PrintString("PUSH [ANALOG]!");
    }
	
	// スタートボタンを押すことでプログラムスタート
    LCD_Char_1_ClearDisplay();
    while(!start)
    {
        PS_Controller_get(PS_data);
        LCD_Char_1_Position(0u, 0u);
        LCD_Char_1_PrintString("PUSH [START]!");
    }
	// 500ms遅延
    //CyDelay(500u);
    
	// LCD clear.
    LCD_Char_1_ClearDisplay();
    
	// I2C master status clear.
    I2C_1_MasterClearStatus();
	
	
	i2c_motor_K[0] = XKbs;
	i2c_motor_K[1] = XKp;
	i2c_motor_K[2] = XKi;
	i2c_motor_K[3] = YKbs;
	i2c_motor_K[4] = YKp;
	i2c_motor_K[5] = YKi;
	i2c_motor_K[6] = ZKbs;
	i2c_motor_K[7] = ZKp;
	i2c_motor_K[8] = ZKi;
	
	//EEPROM_1_Write(i2c_motor_K,0);
	for(j = 0;j < 9;j++)
	{
		i2c_motor_K[j] = CY_GET_XTND_REG8(CYDEV_EE_BASE + j);
	}
	
    reset_kikp();
	
    for(;;)
    {
		// PS2コントローラ(Tiny)から信号受信
        PS_Controller_get(PS_data);
		
		/*** コントローラ信号整形 ***/
		/*
        if(analog_r_x > (127+40))
        {
			#if (VERSION == 0)
            motor_x1 = (analog_r_x-128)*2;
            motor_x2 = 0;
			#endif
			motor_target_speed[MOTOR_X] = (analog_r_x-128);
			motor_target_dir &= (~MOTOR_X_BLAKE); 
        }
        else if(analog_r_x < (127-40))
        {
			#if (VERSION == 0)
            motor_x1 = 0;
            motor_x2 = (127-analog_r_x);
			#endif
			motor_target_speed[MOTOR_X] = -(127-analog_r_x);
			motor_target_dir &= (~MOTOR_X_BLAKE); 
        }
        else
        {
			#if (VERSION == 0)
            motor_x1 = 0;
            motor_x2 = 0;
			#endif
			motor_target_speed[MOTOR_X] = 0;
			motor_target_dir |= (MOTOR_X_BLAKE); 
        }
        */
		if(!automove)
		{
			if(!l1)
			{
				if(left)
				{
					motor_target_speed[MOTOR_X] = -20;
					motor_target_dir &= (~MOTOR_X_BLAKE); 
				}
				else if(right)
				{
					motor_target_speed[MOTOR_X] = 20;
					motor_target_dir &= (~MOTOR_X_BLAKE); 
				}
				else
				{
					motor_target_speed[MOTOR_X] = 0;
					motor_target_dir |= (MOTOR_X_BLAKE); 
				}
			}
			else
			{
				if(left)
				{
					motor_target_speed[MOTOR_X] = -120;
					motor_target_dir &= (~MOTOR_X_BLAKE); 
				}
				else if(right)
				{
					motor_target_speed[MOTOR_X] = 120;
					motor_target_dir &= (~MOTOR_X_BLAKE); 
				}
				else
				{
					motor_target_speed[MOTOR_X] = 0;
					motor_target_dir |= (MOTOR_X_BLAKE); 
				}
			}
			if(!l1)
			{
				if(up)
				{
					motor_target_speed[MOTOR_Y] = 30;
					motor_target_dir &= (~MOTOR_Y_BLAKE);
				}
				else if(down)
				{
					motor_target_speed[MOTOR_Y] = -30;
					motor_target_dir &= (~MOTOR_Y_BLAKE);
				}
				else
				{
					motor_target_speed[MOTOR_Y] = 0;
					motor_target_dir |= (MOTOR_Y_BLAKE);
				}
			}
			else
			{
				if(up)
				{
					motor_target_speed[MOTOR_Y] = 100;
					motor_target_dir &= (~MOTOR_Y_BLAKE);
				}
				else if(down)
				{
					motor_target_speed[MOTOR_Y] = -100;
					motor_target_dir &= (~MOTOR_Y_BLAKE);
				}
				else
				{
					motor_target_speed[MOTOR_Y] = 0;
					motor_target_dir |= (MOTOR_Y_BLAKE);
				}
			}
		}
        if(analog_r_y > (127+40))
        {
			#if (VERSION == 0)
            motor_z1 = (analog_r_y-128)*2;
            motor_z2 = 0;
			#endif
			motor_target_speed[MOTOR_Z] = -(analog_r_y-128);
			motor_target_dir &= (~MOTOR_Z_BLAKE);
        }
        else if(analog_r_y < (127-40))
        {
			#if (VERSION == 0)
            motor_z1 = 0;
            motor_z2 = (127-analog_r_y)*2;
			#endif
			motor_target_speed[MOTOR_Z] = (127-analog_r_y);
			motor_target_dir &= (~MOTOR_Z_BLAKE);
        }
        else
        {
			#if (VERSION == 0)
            motor_z1 = 0;
            motor_z2 = 0;
			#endif
			motor_target_speed[MOTOR_Z] = 0;
			motor_target_dir |= (MOTOR_Z_BLAKE);
        }
		/*
        if(analog_l_y > (127+40))
        {
			#if (VERSION == 0)
            motor_y1 = (analog_l_y-128)*2;
            motor_y2 = 0;
			#endif
			
			if(l1)
			{
				motor_target_speed[MOTOR_Y] = ((analog_l_y-128) >> 2);
			}
			else
			{
			
				motor_target_speed[MOTOR_Y] = (analog_l_y-128);
			}
			motor_target_dir &= (~MOTOR_Y_BLAKE);
        }
        else if(analog_l_y < (127-40))
        {
			#if (VERSION == 0)
            motor_y1 = 0;
            motor_y2 = (127-analog_l_y)*2;
			#endif
			if(l1)
			{
				motor_target_speed[MOTOR_Y] = -((127-analog_l_y) >> 2);
			}
			else
			{
				motor_target_speed[MOTOR_Y] = -(127-analog_l_y);
			}
			motor_target_dir &= (~MOTOR_Y_BLAKE);
        }
        else
        {
			#if (VERSION == 0)
            motor_y1 = 0;
            motor_y2 = 0;
			#endif
			motor_target_speed[MOTOR_Y] = 0;
			motor_target_dir |= (MOTOR_Y_BLAKE);
        }
		*/
		/*** アーム（サーボ,空気,ローラ） ***/
		if(square)
		{
			if(square_flag)
			{
				i2c_servo[ARM_MOTOR] = i2c_servo[ARM_MOTOR] ? 0 : 1;
				square_flag = 0;
			}
		}
		else
		{
			square_flag = 1;
		}
        if(circle && !air_busy)
        {
			// BOX OPEN
			if((box_flag == BOX_CLOSE) && !box_busy && (air_flag == AIR_OPEN))
			{
				box_flag = BOX_OPEN;
				box_busy = 1;
				box_time = time;
				i2c_servo[ARM_BOX_OPEN2] = ARM_BOX_OPEN2_OPEN;
			}
        }
        else if(!circle && !air_busy)
        {
			// BOX CLOSE
			if((box_flag == BOX_OPEN) && !box_busy)
			{
				box_flag = BOX_CLOSE;
				box_busy = 1;
				box_time = time;
				i2c_servo[ARM_BOX_OPEN1] = ARM_BOX_OPEN1_CLOSE;
			}
			if(triangle)
			{
				if(triangle_flag)
				{
					if(!box_busy)
					{
						air_busy = 1;
						air_time = time;
						// air close
						if(air_flag == AIR_OPEN)
						{
							air_flag = AIR_CLOSE;
							i2c_servo[ARM_BOX_KEEP] = ARM_BOX_KEEP_CLOSE;
						}
						// air open
						else
						{
							air_flag = AIR_OPEN;
							i2c_servo[ARM_AIR] = ARM_AIR_OPEN;
						}
					}
					triangle_flag = 0;	
				}
			}
			else
			{
				triangle_flag = 1;
			}
        }
		if(box_flag == BOX_OPEN)
		{
			if(time > box_time + 15)
			{
				i2c_servo[ARM_BOX_OPEN1] = ARM_BOX_OPEN1_OPEN;
				if(time > box_time + 30)
				{
					box_busy = 0;
				}
			}
		}
		if(box_flag == BOX_CLOSE)
		{
			if(time > box_time + 15)
			{
				i2c_servo[ARM_BOX_OPEN2] = ARM_BOX_OPEN2_CLOSE;
				if(time > box_time + 30)
				{
					box_busy = 0;
				}
			}
		}
		if(air_flag == AIR_OPEN)
		{
			if(time > air_time + 15)
			{
				i2c_servo[ARM_BOX_KEEP] = ARM_BOX_KEEP_OPEN;
				if(time > air_time + 30)
				{
					air_busy = 0;
				}
			}
		}
		if(air_flag == AIR_CLOSE)
		{
			if(time > air_time + 30)
			{
				i2c_servo[ARM_AIR] = ARM_AIR_CLOSE;
				if(time > air_time + 15)
				{
					air_busy = 0;
				}
			}
		}
		// アーム裏コマンド
		if(cross)
		{
			if((air_flag == AIR_OPEN) && (box_flag == BOX_CLOSE) && (!box_busy) && (!air_busy))
			{
				i2c_servo[ARM_BOX_KEEP] = 45;
			}
		}
		
		/*** OverDrive ***/
		if(start && select)
		{
			Output_air_Write(1);
		}
		/*** リミットスイッチ ***/
		// back limit
		if(switch_back_Read())
		{
			if(motor_target_speed[MOTOR_Y] < 0)
			{
				motor_target_speed[MOTOR_Y] = 0;
				motor_target_dir |= (MOTOR_Y_BLAKE);
			}
		}
		// front limit
		if(switch_front_Read())
		{
			if(motor_target_speed[MOTOR_Y] > 0)
			{
				motor_target_speed[MOTOR_Y] = 0;
				motor_target_dir |= (MOTOR_Y_BLAKE);
			}
		}
		
		// right limit
		if(switch_right_Read())
		{
			if(motor_target_speed[MOTOR_X] < 0)
			{
				motor_target_speed[MOTOR_X] = 0;
				motor_target_dir |= (MOTOR_X_BLAKE);
			}
		}
		// left limit
		if(switch_left_Read())
		{
			if(motor_target_speed[MOTOR_X] > 0)
			{
				motor_target_speed[MOTOR_X] = 0;
				motor_target_dir |= (MOTOR_X_BLAKE);
			}
		}
		/*
		// up limit
		if(switch_up_Read())
		{
			if(motor_target_speed[MOTOR_Z] > 0)
			{
				motor_target_speed[MOTOR_Z] = 0;
				motor_target_dir |= (MOTOR_Z_BLAKE);
			}
		}
		// down limit
		if(switch_down_Read())
		{
			if(motor_target_speed[MOTOR_Z] < 0)
			{
				motor_target_speed[MOTOR_Z] = 0;
				motor_target_dir |= (MOTOR_Z_BLAKE);
			}
		}
		*/
		// ロリータリセット
		if(l3 && r3)
		{
			// QuadDec_1_SetCounter(0);
			i2c_rori[3] = RORI_RESET;
			Ezi2c_master_write_buf(SLAVE_ADDR_RORI,3,i2c_rori + 3,1);
		}
		
		// 強制ブレーキ
		if(l2 || r2)
		{
			motor_target_dir = 0x07;
		}
		
		/*** 設定UI ***/
		if(automove)
		{
			if(start)
			{
				EEPROM_1_Write(i2c_motor_K,0);
				reset_kikp();
			}
			if(up)
			{
				if(up_flag)
				{
					if(kikpselect_flag == 0)
					{
						if(kikpselect_flag2)
						{
							i2c_motor_K[1]++;
						}
						else
						{
							i2c_motor_K[2]++;
						}
					}
					else if(kikpselect_flag == 1)
					{
						if(kikpselect_flag2)
						{
							i2c_motor_K[4]++;
						}
						else
						{
							i2c_motor_K[5]++;
						}
					}
					else if(kikpselect_flag == 2)
					{
						if(kikpselect_flag2)
						{
							i2c_motor_K[7]++;
						}
						else
						{
							i2c_motor_K[8]++;
						}
					}
					else
					{
						i2c_motor_K[0]++;
						i2c_motor_K[3] = i2c_motor_K[0];
						i2c_motor_K[6] = i2c_motor_K[0];
					}
					up_flag = 0;
				}
			}
			else
			{
				up_flag = 1;
			}
			if(down)
			{
				if(down_flag)
				{
					if(kikpselect_flag == 0)
					{
						if(kikpselect_flag2)
						{
							i2c_motor_K[1]--;
						}
						else
						{
							i2c_motor_K[2]--;
						}
					}
					else if(kikpselect_flag == 1)
					{
						if(kikpselect_flag2)
						{
							i2c_motor_K[4]--;
						}
						else
						{
							i2c_motor_K[5]--;
						}
					}
					else if(kikpselect_flag == 2)
					{
						if(kikpselect_flag2)
						{
							i2c_motor_K[7]--;
						}
						else
						{
							i2c_motor_K[8]--;
						}
					}
					else
					{
						i2c_motor_K[0]--;
						i2c_motor_K[3] = i2c_motor_K[0];
						i2c_motor_K[6] = i2c_motor_K[0];
					}
					down_flag = 0;
				}
			}
			else
			{
				down_flag = 1;
			}
			if(r1)
			{
				if(r1_flag)
				{
					LCD_Char_1_ClearDisplay();
					if(kikpselect_flag < 4)
					{
						kikpselect_flag++;
					}
					else
					{
						kikpselect_flag = 0;
					}
					r1_flag = 0;
				}
			}
			else
			{
				r1_flag = 1;
			}
			if(l1)
			{
				if(l1_flag)
				{
					LCD_Char_1_ClearDisplay();
					if(kikpselect_flag > 0)
					{
						kikpselect_flag--;
					}
					else
					{
						kikpselect_flag = 3;
					}
					l1_flag = 0;
				}
			}
			else
			{
				l1_flag = 1;
			}
			if(left)
			{
				kikpselect_flag2 = 1;
			}
			if(right)
			{
				kikpselect_flag2 = 0;
			}
		}
		
		/*** 自動動作 ***/
		else
		{
			if(up)
			{
				if(up_flag)
				{
					auto_up_flag = auto_down_flag ? 0 : 1;
					up_flag = 0;
				}
			}
			else
			{
				up_flag = 1;
			}
			if(down)
			{
				if(down_flag)
				{
					auto_down_flag = auto_up_flag ? 0 : 1;
					down_flag = 0;
				}
			}
			else
			{
				down_flag = 1;
			}
		}
		// 自動・手動切替
		if(l1 && l2 && r1 && r2)
		{
			if(automove_flag)
			{
				automove = automove^0x01;
				automove_flag = 0;
				LCD_Char_1_ClearDisplay();
			}
		}
		else
		{
			automove_flag = 1;
		}
		
		// ポーリングプログラム
		if(isr_1_flag == 1)
		{
			time++;
			status[0] = Ezi2c_master_read_buf(SLAVE_ADDR_RORI,0,i2c_rori,4);
			status[0] = Ezi2c_master_write_buf(SLAVE_ADDR_SERVO,0,i2c_servo,7);
			i2c_motor[0] = motor_target_dir;
			for(i = 1;i <= 3;i++)
			{
				i2c_motor[i] = motor_target_speed[i];
			}
			
			i = I2CIO_TRY_COMMUNICATION;
			do{
				status[1] = Ezi2c_master_read_buf(SLAVE_ADDR_MOTOR,0x00,i2c_motor_config,2);
				if(!(i2c_motor_config[0] & I2CIO_BUSY))
				{
					status[1] = Ezi2c_master_read_buf(SLAVE_ADDR_MOTOR,I2CIO_OUTBOX_ADDR,&i2c_outbox_flag,1);
					i2c_outbox_flag |= I2CIO_WRITE;
					status[2] = Ezi2c_master_write_buf(SLAVE_ADDR_MOTOR,I2CIO_OUTBOX_ADDR,&i2c_outbox_flag,1);
					status[3] = Ezi2c_master_read_buf(SLAVE_ADDR_MOTOR,I2CIO_OUTBOX_ADDR,&i2c_outbox_flag,1);
					if(!(i2c_outbox_flag & I2CIO_READ))
					{
        				status[4] = Ezi2c_master_write_buf(SLAVE_ADDR_MOTOR,0x03,i2c_motor,4);
						status[5] = Ezi2c_master_read_buf(SLAVE_ADDR_MOTOR,I2CIO_OUTBOX_ADDR,&i2c_outbox_flag,1);
						i2c_outbox_flag &= (~I2CIO_WRITE);
						i2c_outbox_flag |= I2CIO_UPDATE;
						status[6] = Ezi2c_master_write_buf(SLAVE_ADDR_MOTOR,I2CIO_OUTBOX_ADDR,&i2c_outbox_flag,1);
						i = 0;
						i2c_motor_status = 0;
        			}
					else
					{
						i2c_outbox_flag &= (~I2CIO_WRITE);
						status[7] = Ezi2c_master_write_buf(SLAVE_ADDR_MOTOR,I2CIO_OUTBOX_ADDR,&i2c_outbox_flag,1);
						i--;
						i2c_motor_status = 1;
					}
				}
				else
				{
					i--;
					i2c_motor_status = 2;
				}
			}while(i > 0);
			//status = Ezi2c_master_write_buf(22,0,i2c_servo,1);
			
        	isr_1_flag = 0;
		}
		
		LCD_Char_1_WriteControl(LCD_Char_1_DISPLAY_ON_CURSOR_OFF);
        LCD_Char_1_Position(0u, 0u);
        LCD_Char_1_PrintString("B:");
        LCD_Char_1_PrintInt8(i2c_motor[0]);
        LCD_Char_1_PrintString(" M:");
        LCD_Char_1_PrintInt8(i2c_motor[1]);
        LCD_Char_1_PrintString(" ");
        LCD_Char_1_PrintInt8(i2c_motor[2]);
        LCD_Char_1_PrintString(" ");
        LCD_Char_1_PrintInt8(i2c_motor[3]);
		LCD_Char_1_Position(1u, 0u);
		if(automove)
		{
			if(kikpselect_flag == 0)
			{
	        	LCD_Char_1_PrintString(" XKp:");
	        	LCD_Char_1_PrintInt8(i2c_motor_K[1]);
				LCD_Char_1_PrintString("  XKi:");
	        	LCD_Char_1_PrintInt8(i2c_motor_K[2]);
			}
			else if(kikpselect_flag == 1)
			{
				LCD_Char_1_PrintString(" YKp:");
	        	LCD_Char_1_PrintInt8(i2c_motor_K[4]);
				LCD_Char_1_PrintString("  YKi:");
	        	LCD_Char_1_PrintInt8(i2c_motor_K[5]);
			}
			else if(kikpselect_flag == 2)
			{
				LCD_Char_1_PrintString(" ZKp:");
	        	LCD_Char_1_PrintInt8(i2c_motor_K[7]);
				LCD_Char_1_PrintString("  ZKi:");
	        	LCD_Char_1_PrintInt8(i2c_motor_K[8]);
			}
			else
			{
				LCD_Char_1_PrintString("2^x:");
	        	LCD_Char_1_PrintInt8(i2c_motor_K[0]);
				LCD_Char_1_PrintString(",");
				LCD_Char_1_PrintInt8(i2c_motor_K[3]);
				LCD_Char_1_PrintString(",");
				LCD_Char_1_PrintInt8(i2c_motor_K[6]);
			}
			if(kikpselect_flag2)
			{
				LCD_Char_1_Position(1u, 0u);
			}
			else
			{
				LCD_Char_1_Position(1u, 8u);
			}
			if(kikpselect_flag != 3)
			{
				LCD_Char_1_WriteControl(LCD_Char_1_CURSOR_WINK);
			}
		}
		else
		{
			LCD_Char_1_PrintString("RORI:");
	        LCD_Char_1_PrintInt8(i2c_rori[0]);
			LCD_Char_1_PrintInt8(i2c_rori[1]);
			LCD_Char_1_PrintString(" s:");
			LCD_Char_1_PrintInt8(status[0]);
		}
		//LCD_Char_1_PrintString(" Q:");
		//LCD_Char_1_PrintInt16(QuadDec_1_GetCounter());
		
		/*
		LCD_Char_1_Position(1u, 0u);
		for(i = 0;i < 7;i++)
		{
			LCD_Char_1_PrintInt8(status[i]);
		}
		*/
    }
}
// EzI2C　master　read　function.
// PSoC 1 onry.
uint8 Ezi2c_master_write_buf(uint8 addr,uint8 data_addr,uint8* wrdata,uint8 cnt)
{
    uint8 status;
    uint8 i;
    
    status = I2C_1_MasterSendStart(addr, I2C_1_WRITE_XFER_MODE);
    if(status == I2C_1_MSTR_NO_ERROR) /* Check if transfer completed without errors */
    {
        status = I2C_1_MasterWriteByte(data_addr);
        if(status != I2C_1_MSTR_NO_ERROR)
        {
            I2C_1_MasterSendStop();
            return status;
        }
        for(i=0; i < cnt; i++)
        {
            status = I2C_1_MasterWriteByte(wrdata[i]);
            if(status != I2C_1_MSTR_NO_ERROR)
            {
				I2C_1_MasterSendStop();
                return status;
            }
        }
    }
    I2C_1_MasterSendStop();
    return status;
}

// EzI2C　master　read　function.
// PSoC 1 onry.
uint8 Ezi2c_master_read_buf(uint8 addr,uint8 data_addr,uint8* redata,uint8 cnt)
{
    uint8 status;
    uint8 i;
    status = I2C_1_MasterSendStart(addr, I2C_1_WRITE_XFER_MODE);
    if(status == I2C_1_MSTR_NO_ERROR) /* Check if transfer completed without errors */
    {
        status = I2C_1_MasterWriteByte(data_addr);
        if(status != I2C_1_MSTR_NO_ERROR)
        {
            I2C_1_MasterSendStop();
            return status;
        }
    }
	else
	{
		I2C_1_MasterSendStop();
		return status;
	}
    I2C_1_MasterSendStop();
    status = I2C_1_MasterSendStart(addr, I2C_1_READ_XFER_MODE);
    if(status == I2C_1_MSTR_NO_ERROR) /* Check if transfer completed without errors */
    {
        //I2C_1_MasterReadByte(I2C_1_ACK_DATA); /* 相手がPSoC3の場合 */
        for(i=0; i < cnt; i++)
        {
            if(i < cnt-1 )
            {
                redata[i] = I2C_1_MasterReadByte(I2C_1_ACK_DATA);
            }
            else
            {
                redata[i] = I2C_1_MasterReadByte(I2C_1_NAK_DATA);
            }
			while((I2C_1_MasterStatus() & I2C_1_MSTAT_XFER_INP) != I2C_1_MSTAT_XFER_INP);
			if((I2C_1_MasterStatus() & I2C_1_MSTAT_ERR_XFER) != 0)
			{
				status = I2C_1_MasterSendStop();
				return status;
			}
        }
    }
    I2C_1_MasterSendStop(); /* Send Stop */
    return status;
}

// PS2コントラーラ信号受信関数
// キモいことしてますが動きます。
// 割り込みでやるべき？
uint8 PS_Controller_get(uint8* SwitchRecv)
{
    
    uint16 buff;
    uint16 udata;
    uint16 temp;
    uint8 i = 0;
    uint16 timeout_t = 0;
    UART_1_ClearRxBuffer();
    for(i = 0;i < 12;i++)
    {
        //if(i >= 8)
        //{
        //    return 1;
        //}
        timeout_t = 0;
        while(UART_1_GetRxBufferSize() <= 8)
        {
            if(timeout_t < 10000)
            {
                timeout_t++;
            }
            else
            {
                return 2;
            }
            CyDelayUs(1);
        }
        if((UART_1_ReadRxData() & 0x0F) == 0x0F)
        {
            break;
        }
    }
    for(i = 0;i < 12;i++)
    {
        timeout_t = 0;
        while(UART_1_GetRxBufferSize() <= 8)
        {
            if(timeout_t < 10000)
            {
                timeout_t++;
            }
            else
            {
                return 3;
            }
            CyDelayUs(1);
        }
        udata = UART_1_ReadRxData();
        if(!(udata & 0x08)){
            buff = udata;
            continue;
        }
        if((udata & 0x07)==(buff & 0x07)){
            temp  = buff & 0xF0;
            temp |= udata >> 4;
            SwitchRecv[udata & 0x07] = temp;
        }
        /*
        if(udata & 0x0f == 0x0f)
        {
            return 0;
        }
        */
    }
    return -1;
}
void reset_kikp()
{
	uint8 i;
	i = I2CIO_TRY_COMMUNICATION;
	do{
		Ezi2c_master_read_buf(SLAVE_ADDR_MOTOR,0x00,i2c_motor_config,2);
		if(!(i2c_motor_config[0] & I2CIO_BUSY))
		{
			Ezi2c_master_read_buf(SLAVE_ADDR_MOTOR,I2CIO_OUTBOX_ADDR,&i2c_outbox_flag,1);
			i2c_outbox_flag |= I2CIO_WRITE;
			Ezi2c_master_write_buf(SLAVE_ADDR_MOTOR,I2CIO_OUTBOX_ADDR,&i2c_outbox_flag,1);
			Ezi2c_master_read_buf(SLAVE_ADDR_MOTOR,I2CIO_OUTBOX_ADDR,&i2c_outbox_flag,1);
			if(!(i2c_outbox_flag & I2CIO_READ))
			{
    			Ezi2c_master_write_buf(SLAVE_ADDR_MOTOR,0x07,i2c_motor_K,9);
				Ezi2c_master_read_buf(SLAVE_ADDR_MOTOR,I2CIO_OUTBOX_ADDR,&i2c_outbox_flag,1);
				i2c_outbox_flag &= (~I2CIO_WRITE);
				i2c_outbox_flag |= I2CIO_UPDATE;
				Ezi2c_master_write_buf(SLAVE_ADDR_MOTOR,I2CIO_OUTBOX_ADDR,&i2c_outbox_flag,1);
				i = 0;
				i2c_motor_status = 0;
    		}
			else
			{
				i2c_outbox_flag &= (~I2CIO_WRITE);
				Ezi2c_master_write_buf(SLAVE_ADDR_MOTOR,I2CIO_OUTBOX_ADDR,&i2c_outbox_flag,1);
				i--;
				i2c_motor_status = 1;
			}
		}
		else
		{
			i--;
			i2c_motor_status = 2;
		}
	}while(i > 0);
}
/* [] END OF FILE */
