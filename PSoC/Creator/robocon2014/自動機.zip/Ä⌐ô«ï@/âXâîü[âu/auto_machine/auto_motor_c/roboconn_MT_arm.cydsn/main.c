/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include <stdlib.h>

uint8 buffer[32];

void Wrist_Motor(int16 pwm); // pwm -255 ~ 255
void Wrist_Brake();
void Rail_Motor(int16 pwm); // pwm -255 ~ 255

uint8 clock_flag;

void LIN_Slave_init()
{
	if(0u != l_sys_init()){
		
		CyHalt(0x00);
		
	}
	
	if(0u != l_ifc_init(LIN_1_IFC_HANDLE)){
	
		CyHalt(0x00);
		
	}
}
CY_ISR(clock_isr)
{
	clock_flag = 1;
}
int main()
{
    int16 Wrist_position = 0;
	double det_operation;
	double det_date1;
	double det_date2;
	double det_i;
	int16 target = 450; //0~900
	const int16 target_max = 900;
	double kp = 0.20;
	double ki = 0.3;
	double kid = 0.2;
	
    CyGlobalIntEnable;  /* Uncomment this line to enable global interrupts. */
	PWM_1_Start();
	PWM_2_Start();
	LIN_Slave_init();
	ADC_DelSig_1_Start();
	ADC_DelSig_1_StartConvert();
	isr_1_StartEx(clock_isr);
	UART_1_Start();
	UART_1_EnableTxInt();
	
    for(;;)
    {
		if(l_flg_tst_target() == 1)
		{	
			target = l_u8_rd_target() * (target_max / 64);
			//target = l_u8_rd_target();
		}
		if(target > 700)
		{
			target = 700;
		}
		else if(target < 0)
		{
			target = 0; 
		}
		if(ADC_DelSig_1_IsEndConversion(ADC_DelSig_1_RETURN_STATUS))
        {
            Wrist_position = ADC_DelSig_1_GetResult16() - 200; // 1830 ~ 2000
			ADC_DelSig_1_StartConvert();
        }
		
		if(UART_1_ReadTxStatus() & UART_1_TX_STS_FIFO_EMPTY)
		{
			sprintf(buffer,"target %5d posi %5d,det_date1 %5d,ope %5d,det_i %5d\n",(int)target,(int16)Wrist_position,(int16)det_date1,(int16)det_operation,(int16)det_i);
			//sprintf(buffer,"target %d status 0x%x\n",(int)target,(int)l_ifc_read_status());
			UART_1_PutString(buffer);
		}
		if(clock_flag)
		{
			//target 0 ~ 150
			det_date1 = -(target - Wrist_position);
			
			///////////////////////操作量/////////////////
			//det_operation = (det_date1 - det_date2) * 1 / 2 + det_date1 * 1 / 3 ;
			//operation += det_operation;
			//det_date2 = det_date1;
			if((det_i < 256) && (det_i > -256)){
				det_i += det_date1*ki;
			}
			if(det_i > 255)
			{
				det_i = 255;
			}
			if(det_i < -255)
			{
				det_i = -255;
			}
			det_operation = det_date1*kp + det_i*(kid);
			det_date2 = det_date1;
			////////目標値に達成///////////////
			if ((det_date1 < 30) && (det_date1 > -30)) {
				Wrist_Brake();
			}
			
			/////////目標値とずれていた場合/////////////
			else{
				Wrist_Motor((int16)(det_operation));
			}
			clock_flag = 0;
		}
		//Wrist_Motor(125);
		Rail_Motor(0);
    }
}

void Wrist_Motor(int16 pwm) // pwm -255 ~ 255
{
	if(pwm > 255)
	{
		pwm = 255;
	}
	if(pwm < -255)
	{
		pwm = -255;
	}
	if(pwm > 0)
	{	
		PWM_1_WriteCompare1((uint8)(pwm));
		PWM_1_WriteCompare2(0);
	}
	else if(pwm < 0)
	{
		PWM_1_WriteCompare1(0);
		PWM_1_WriteCompare2((uint8)(-pwm));
	}
}
void Wrist_Brake()
{
	PWM_1_WriteCompare1(255);
	PWM_1_WriteCompare2(255);
}
void Rail_Motor(int16 pwm) // pwm -255 ~ 255
{
	if(pwm > 255)
	{
		pwm = 255;
	}
	if(pwm < -255)
	{
		pwm = -255;
	}
	if(pwm > 0)
	{	
		PWM_2_WriteCompare1((uint8)(pwm));
		PWM_2_WriteCompare2(0);
	}
	else if(pwm < 0)
	{
		PWM_2_WriteCompare1(0);
		PWM_2_WriteCompare2((uint8)(-pwm));
	}
}