/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include <stdlib.h>

uint8 buffer[32];
int16 count1,rpm,test_rpm=3500;
int16 operation = 5000;
uint16 i_data,target = 4000,t=0;
int16 det_rpm1 = 0,det_rpm2 = 0;
double det_operation = 0.0;
CY_ISR(motor_isr)
{
	count1 = QuadDec_1_GetCounter();
	QuadDec_1_SetCounter(0);
	rpm = count1 * 15;// /400*100*60
	/////目標値との差分//////////////
	det_rpm1 = target - rpm;
	/////操作量を計算////////////////
	det_operation = (((det_rpm1 - det_rpm2) * 0.2) + (det_rpm1 * 0.5));
    operation = operation + (int16)(det_operation*0.1);
	det_rpm2 = det_rpm1;
	/////モータの出力制限/////////////
	if(operation <= -4500)
	{
		operation = -4500;
	}
	else if(operation >=4500)
	{
		operation = 4500;
	}
	/////PWM出力値変更///////////
	PWM_A_WriteCompare1(5000+(int16)operation);
	PWM_A_WriteCompare2(5000-(int16)operation);
	//////timeとrpm表示///////////
	if(UART_1_ReadTxStatus() & UART_1_TX_STS_FIFO_EMPTY)
	{
		sprintf(buffer,"%d , %d\n",t,rpm);
		UART_1_PutString(buffer);
	}
	t++;
}

/*	

void roricon(void){
	
	count1 = QuadDec_1_GetCounter();
	sprintf(buffer,"data = %d \n",count1);
	if(USBUART_1_CDCIsReady() != 0u)
	USBUART_1_PutString(buffer);
	QuadDec_1_SetCounter(0);
	
}
*/

int main()
{

	CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
	PWM_A_Start();
	QuadDec_1_Start();
//	ADC_DelSig_1_Start();
	isr_2_StartEx(motor_isr);
	UART_1_Start();
	UART_1_EnableTxInt();
    for(;;)
    {
//		ADC_DelSig_1_StartConvert();
//		while(ADC_DelSig_1_IsEndConversion(ADC_DelSig_1_WAIT_FOR_RESULT) == 0);
//		i_data = ADC_DelSig_1_GetResult16();
		
		
		
	}
}

/* [] END OF FILE */
