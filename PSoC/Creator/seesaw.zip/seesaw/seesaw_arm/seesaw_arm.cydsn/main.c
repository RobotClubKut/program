/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include <stdlib.h>

int timer_flag = 0; 
int	pulse_count = 0;
uint8 buffer[32];
/////モータ駆動//////////////////

void motor_up_down(int motor_up_value,int motor_down_value)
{

	PWM_1_WriteCompare1(motor_down_value);
	PWM_1_WriteCompare2(motor_up_value);
	
}

void motor_front_back(int motor_front_value,int motor_back_value)
{

	PWM_2_WriteCompare1(motor_front_value);
	PWM_2_WriteCompare2(motor_back_value);
	
}

/////LIN/////////////////////

void LIN_Slave_init()
{
	if(0u != l_sys_init()){
		
		CyHalt(0x00);
		
	}
	
	if(0u != l_ifc_init(LIN_1_IFC_HANDLE)){
	
		CyHalt(0x00);
		
	}
}


int main()
{
	
	int i = 0;
	uint8 motor_status = 0;
	uint8 motor_up_down_flag = 0;
	uint8 motor_front_back_flag = 0;


    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
	
	CyGlobalIntEnable; 
	PWM_1_Start();
	PWM_2_Start();
//	QuadDec_1_Start();
	LIN_Slave_init();
//	isr_1_StartEx(motor_isr);
	UART_1_Start();
	UART_1_EnableTxInt();
  
  	
	
	/////main////////////////////////
	
	for(;;){
	
		/////マスターからモータ状態データ取得/////////////////
		if(!(l_flg_tst_seesaw_motor_status() == 0))
		{
			
			motor_status = l_u8_rd_seesaw_motor_status();
			l_flg_clr_seesaw_motor_status();

		}
			
		/////UP/////////////////////////////
		if((!(motor_status & (1 << 7))) && (motor_up_down_flag == 0))
		{
			
			while(!(UP_LIMIT_Read() == 1))
			{
				motor_up_down(120,0);
			}
	
			motor_up_down(0,0);
            CyDelay(500);
			motor_up_down_flag = 1;
			
		}
		
		/////DOWN/////////////////////////////
		else if((motor_status & (1 << 7)) && (motor_up_down_flag == 1))
		{
			
			while(!(DOWN_LIMIT_Read() == 1))
			{
				motor_up_down(0,100);
			}
	
			motor_up_down(0,0);
            CyDelay(500);
			motor_up_down_flag = 0;
			
		}
		
		/////FRONT//////////////////////////
		
		if((motor_status & (1 << 6)) && (motor_front_back_flag == 0))
		{
			
			while(!(FRONT_LIMIT_Read() == 1))
			{
				motor_front_back(50,0);///250///50
			}
		
			motor_front_back(0,0);
			motor_front_back_flag = 1;
		}
		
		/////BACK/////////////////////
		
		else if((!(motor_status & (1 << 6))) && (motor_front_back_flag == 1))
		{
			
			while(!(BACK_LIMIT_Read() == 1))
			{
				motor_front_back(0,50);///200///50
			}
			motor_front_back(0,0);
			motor_front_back_flag = 0;
			
		}
//		sprintf(buffer,"%6d\n",motor_status);
//		UART_1_PutString(buffer);
	}
}
	


/* [] END OF FILE */
