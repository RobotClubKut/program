/*******************************************************************************
* File Name: L12.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_L12_H) /* Pins L12_H */
#define CY_PINS_L12_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "L12_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    L12_Write(uint8 value) ;
void    L12_SetDriveMode(uint8 mode) ;
uint8   L12_ReadDataReg(void) ;
uint8   L12_Read(void) ;
uint8   L12_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define L12_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define L12_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define L12_DM_RES_UP          PIN_DM_RES_UP
#define L12_DM_RES_DWN         PIN_DM_RES_DWN
#define L12_DM_OD_LO           PIN_DM_OD_LO
#define L12_DM_OD_HI           PIN_DM_OD_HI
#define L12_DM_STRONG          PIN_DM_STRONG
#define L12_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define L12_MASK               L12__MASK
#define L12_SHIFT              L12__SHIFT
#define L12_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define L12_PS                     (* (reg8 *) L12__PS)
/* Data Register */
#define L12_DR                     (* (reg8 *) L12__DR)
/* Port Number */
#define L12_PRT_NUM                (* (reg8 *) L12__PRT) 
/* Connect to Analog Globals */                                                  
#define L12_AG                     (* (reg8 *) L12__AG)                       
/* Analog MUX bux enable */
#define L12_AMUX                   (* (reg8 *) L12__AMUX) 
/* Bidirectional Enable */                                                        
#define L12_BIE                    (* (reg8 *) L12__BIE)
/* Bit-mask for Aliased Register Access */
#define L12_BIT_MASK               (* (reg8 *) L12__BIT_MASK)
/* Bypass Enable */
#define L12_BYP                    (* (reg8 *) L12__BYP)
/* Port wide control signals */                                                   
#define L12_CTL                    (* (reg8 *) L12__CTL)
/* Drive Modes */
#define L12_DM0                    (* (reg8 *) L12__DM0) 
#define L12_DM1                    (* (reg8 *) L12__DM1)
#define L12_DM2                    (* (reg8 *) L12__DM2) 
/* Input Buffer Disable Override */
#define L12_INP_DIS                (* (reg8 *) L12__INP_DIS)
/* LCD Common or Segment Drive */
#define L12_LCD_COM_SEG            (* (reg8 *) L12__LCD_COM_SEG)
/* Enable Segment LCD */
#define L12_LCD_EN                 (* (reg8 *) L12__LCD_EN)
/* Slew Rate Control */
#define L12_SLW                    (* (reg8 *) L12__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define L12_PRTDSI__CAPS_SEL       (* (reg8 *) L12__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define L12_PRTDSI__DBL_SYNC_IN    (* (reg8 *) L12__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define L12_PRTDSI__OE_SEL0        (* (reg8 *) L12__PRTDSI__OE_SEL0) 
#define L12_PRTDSI__OE_SEL1        (* (reg8 *) L12__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define L12_PRTDSI__OUT_SEL0       (* (reg8 *) L12__PRTDSI__OUT_SEL0) 
#define L12_PRTDSI__OUT_SEL1       (* (reg8 *) L12__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define L12_PRTDSI__SYNC_OUT       (* (reg8 *) L12__PRTDSI__SYNC_OUT) 


#if defined(L12__INTSTAT)  /* Interrupt Registers */

    #define L12_INTSTAT                (* (reg8 *) L12__INTSTAT)
    #define L12_SNAP                   (* (reg8 *) L12__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins L12_H */


/* [] END OF FILE */
