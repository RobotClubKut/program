/*******************************************************************************
* File Name: L14.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_L14_H) /* Pins L14_H */
#define CY_PINS_L14_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "L14_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    L14_Write(uint8 value) ;
void    L14_SetDriveMode(uint8 mode) ;
uint8   L14_ReadDataReg(void) ;
uint8   L14_Read(void) ;
uint8   L14_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define L14_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define L14_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define L14_DM_RES_UP          PIN_DM_RES_UP
#define L14_DM_RES_DWN         PIN_DM_RES_DWN
#define L14_DM_OD_LO           PIN_DM_OD_LO
#define L14_DM_OD_HI           PIN_DM_OD_HI
#define L14_DM_STRONG          PIN_DM_STRONG
#define L14_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define L14_MASK               L14__MASK
#define L14_SHIFT              L14__SHIFT
#define L14_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define L14_PS                     (* (reg8 *) L14__PS)
/* Data Register */
#define L14_DR                     (* (reg8 *) L14__DR)
/* Port Number */
#define L14_PRT_NUM                (* (reg8 *) L14__PRT) 
/* Connect to Analog Globals */                                                  
#define L14_AG                     (* (reg8 *) L14__AG)                       
/* Analog MUX bux enable */
#define L14_AMUX                   (* (reg8 *) L14__AMUX) 
/* Bidirectional Enable */                                                        
#define L14_BIE                    (* (reg8 *) L14__BIE)
/* Bit-mask for Aliased Register Access */
#define L14_BIT_MASK               (* (reg8 *) L14__BIT_MASK)
/* Bypass Enable */
#define L14_BYP                    (* (reg8 *) L14__BYP)
/* Port wide control signals */                                                   
#define L14_CTL                    (* (reg8 *) L14__CTL)
/* Drive Modes */
#define L14_DM0                    (* (reg8 *) L14__DM0) 
#define L14_DM1                    (* (reg8 *) L14__DM1)
#define L14_DM2                    (* (reg8 *) L14__DM2) 
/* Input Buffer Disable Override */
#define L14_INP_DIS                (* (reg8 *) L14__INP_DIS)
/* LCD Common or Segment Drive */
#define L14_LCD_COM_SEG            (* (reg8 *) L14__LCD_COM_SEG)
/* Enable Segment LCD */
#define L14_LCD_EN                 (* (reg8 *) L14__LCD_EN)
/* Slew Rate Control */
#define L14_SLW                    (* (reg8 *) L14__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define L14_PRTDSI__CAPS_SEL       (* (reg8 *) L14__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define L14_PRTDSI__DBL_SYNC_IN    (* (reg8 *) L14__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define L14_PRTDSI__OE_SEL0        (* (reg8 *) L14__PRTDSI__OE_SEL0) 
#define L14_PRTDSI__OE_SEL1        (* (reg8 *) L14__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define L14_PRTDSI__OUT_SEL0       (* (reg8 *) L14__PRTDSI__OUT_SEL0) 
#define L14_PRTDSI__OUT_SEL1       (* (reg8 *) L14__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define L14_PRTDSI__SYNC_OUT       (* (reg8 *) L14__PRTDSI__SYNC_OUT) 


#if defined(L14__INTSTAT)  /* Interrupt Registers */

    #define L14_INTSTAT                (* (reg8 *) L14__INTSTAT)
    #define L14_SNAP                   (* (reg8 *) L14__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins L14_H */


/* [] END OF FILE */
