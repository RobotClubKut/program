/*******************************************************************************
* File Name: L16.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_L16_H) /* Pins L16_H */
#define CY_PINS_L16_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "L16_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    L16_Write(uint8 value) ;
void    L16_SetDriveMode(uint8 mode) ;
uint8   L16_ReadDataReg(void) ;
uint8   L16_Read(void) ;
uint8   L16_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define L16_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define L16_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define L16_DM_RES_UP          PIN_DM_RES_UP
#define L16_DM_RES_DWN         PIN_DM_RES_DWN
#define L16_DM_OD_LO           PIN_DM_OD_LO
#define L16_DM_OD_HI           PIN_DM_OD_HI
#define L16_DM_STRONG          PIN_DM_STRONG
#define L16_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define L16_MASK               L16__MASK
#define L16_SHIFT              L16__SHIFT
#define L16_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define L16_PS                     (* (reg8 *) L16__PS)
/* Data Register */
#define L16_DR                     (* (reg8 *) L16__DR)
/* Port Number */
#define L16_PRT_NUM                (* (reg8 *) L16__PRT) 
/* Connect to Analog Globals */                                                  
#define L16_AG                     (* (reg8 *) L16__AG)                       
/* Analog MUX bux enable */
#define L16_AMUX                   (* (reg8 *) L16__AMUX) 
/* Bidirectional Enable */                                                        
#define L16_BIE                    (* (reg8 *) L16__BIE)
/* Bit-mask for Aliased Register Access */
#define L16_BIT_MASK               (* (reg8 *) L16__BIT_MASK)
/* Bypass Enable */
#define L16_BYP                    (* (reg8 *) L16__BYP)
/* Port wide control signals */                                                   
#define L16_CTL                    (* (reg8 *) L16__CTL)
/* Drive Modes */
#define L16_DM0                    (* (reg8 *) L16__DM0) 
#define L16_DM1                    (* (reg8 *) L16__DM1)
#define L16_DM2                    (* (reg8 *) L16__DM2) 
/* Input Buffer Disable Override */
#define L16_INP_DIS                (* (reg8 *) L16__INP_DIS)
/* LCD Common or Segment Drive */
#define L16_LCD_COM_SEG            (* (reg8 *) L16__LCD_COM_SEG)
/* Enable Segment LCD */
#define L16_LCD_EN                 (* (reg8 *) L16__LCD_EN)
/* Slew Rate Control */
#define L16_SLW                    (* (reg8 *) L16__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define L16_PRTDSI__CAPS_SEL       (* (reg8 *) L16__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define L16_PRTDSI__DBL_SYNC_IN    (* (reg8 *) L16__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define L16_PRTDSI__OE_SEL0        (* (reg8 *) L16__PRTDSI__OE_SEL0) 
#define L16_PRTDSI__OE_SEL1        (* (reg8 *) L16__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define L16_PRTDSI__OUT_SEL0       (* (reg8 *) L16__PRTDSI__OUT_SEL0) 
#define L16_PRTDSI__OUT_SEL1       (* (reg8 *) L16__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define L16_PRTDSI__SYNC_OUT       (* (reg8 *) L16__PRTDSI__SYNC_OUT) 


#if defined(L16__INTSTAT)  /* Interrupt Registers */

    #define L16_INTSTAT                (* (reg8 *) L16__INTSTAT)
    #define L16_SNAP                   (* (reg8 *) L16__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins L16_H */


/* [] END OF FILE */
