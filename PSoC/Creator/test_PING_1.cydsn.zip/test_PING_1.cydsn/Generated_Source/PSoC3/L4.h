/*******************************************************************************
* File Name: L4.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_L4_H) /* Pins L4_H */
#define CY_PINS_L4_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "L4_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    L4_Write(uint8 value) ;
void    L4_SetDriveMode(uint8 mode) ;
uint8   L4_ReadDataReg(void) ;
uint8   L4_Read(void) ;
uint8   L4_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define L4_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define L4_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define L4_DM_RES_UP          PIN_DM_RES_UP
#define L4_DM_RES_DWN         PIN_DM_RES_DWN
#define L4_DM_OD_LO           PIN_DM_OD_LO
#define L4_DM_OD_HI           PIN_DM_OD_HI
#define L4_DM_STRONG          PIN_DM_STRONG
#define L4_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define L4_MASK               L4__MASK
#define L4_SHIFT              L4__SHIFT
#define L4_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define L4_PS                     (* (reg8 *) L4__PS)
/* Data Register */
#define L4_DR                     (* (reg8 *) L4__DR)
/* Port Number */
#define L4_PRT_NUM                (* (reg8 *) L4__PRT) 
/* Connect to Analog Globals */                                                  
#define L4_AG                     (* (reg8 *) L4__AG)                       
/* Analog MUX bux enable */
#define L4_AMUX                   (* (reg8 *) L4__AMUX) 
/* Bidirectional Enable */                                                        
#define L4_BIE                    (* (reg8 *) L4__BIE)
/* Bit-mask for Aliased Register Access */
#define L4_BIT_MASK               (* (reg8 *) L4__BIT_MASK)
/* Bypass Enable */
#define L4_BYP                    (* (reg8 *) L4__BYP)
/* Port wide control signals */                                                   
#define L4_CTL                    (* (reg8 *) L4__CTL)
/* Drive Modes */
#define L4_DM0                    (* (reg8 *) L4__DM0) 
#define L4_DM1                    (* (reg8 *) L4__DM1)
#define L4_DM2                    (* (reg8 *) L4__DM2) 
/* Input Buffer Disable Override */
#define L4_INP_DIS                (* (reg8 *) L4__INP_DIS)
/* LCD Common or Segment Drive */
#define L4_LCD_COM_SEG            (* (reg8 *) L4__LCD_COM_SEG)
/* Enable Segment LCD */
#define L4_LCD_EN                 (* (reg8 *) L4__LCD_EN)
/* Slew Rate Control */
#define L4_SLW                    (* (reg8 *) L4__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define L4_PRTDSI__CAPS_SEL       (* (reg8 *) L4__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define L4_PRTDSI__DBL_SYNC_IN    (* (reg8 *) L4__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define L4_PRTDSI__OE_SEL0        (* (reg8 *) L4__PRTDSI__OE_SEL0) 
#define L4_PRTDSI__OE_SEL1        (* (reg8 *) L4__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define L4_PRTDSI__OUT_SEL0       (* (reg8 *) L4__PRTDSI__OUT_SEL0) 
#define L4_PRTDSI__OUT_SEL1       (* (reg8 *) L4__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define L4_PRTDSI__SYNC_OUT       (* (reg8 *) L4__PRTDSI__SYNC_OUT) 


#if defined(L4__INTSTAT)  /* Interrupt Registers */

    #define L4_INTSTAT                (* (reg8 *) L4__INTSTAT)
    #define L4_SNAP                   (* (reg8 *) L4__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins L4_H */


/* [] END OF FILE */
