/*******************************************************************************
* File Name: L5.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_L5_H) /* Pins L5_H */
#define CY_PINS_L5_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "L5_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    L5_Write(uint8 value) ;
void    L5_SetDriveMode(uint8 mode) ;
uint8   L5_ReadDataReg(void) ;
uint8   L5_Read(void) ;
uint8   L5_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define L5_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define L5_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define L5_DM_RES_UP          PIN_DM_RES_UP
#define L5_DM_RES_DWN         PIN_DM_RES_DWN
#define L5_DM_OD_LO           PIN_DM_OD_LO
#define L5_DM_OD_HI           PIN_DM_OD_HI
#define L5_DM_STRONG          PIN_DM_STRONG
#define L5_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define L5_MASK               L5__MASK
#define L5_SHIFT              L5__SHIFT
#define L5_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define L5_PS                     (* (reg8 *) L5__PS)
/* Data Register */
#define L5_DR                     (* (reg8 *) L5__DR)
/* Port Number */
#define L5_PRT_NUM                (* (reg8 *) L5__PRT) 
/* Connect to Analog Globals */                                                  
#define L5_AG                     (* (reg8 *) L5__AG)                       
/* Analog MUX bux enable */
#define L5_AMUX                   (* (reg8 *) L5__AMUX) 
/* Bidirectional Enable */                                                        
#define L5_BIE                    (* (reg8 *) L5__BIE)
/* Bit-mask for Aliased Register Access */
#define L5_BIT_MASK               (* (reg8 *) L5__BIT_MASK)
/* Bypass Enable */
#define L5_BYP                    (* (reg8 *) L5__BYP)
/* Port wide control signals */                                                   
#define L5_CTL                    (* (reg8 *) L5__CTL)
/* Drive Modes */
#define L5_DM0                    (* (reg8 *) L5__DM0) 
#define L5_DM1                    (* (reg8 *) L5__DM1)
#define L5_DM2                    (* (reg8 *) L5__DM2) 
/* Input Buffer Disable Override */
#define L5_INP_DIS                (* (reg8 *) L5__INP_DIS)
/* LCD Common or Segment Drive */
#define L5_LCD_COM_SEG            (* (reg8 *) L5__LCD_COM_SEG)
/* Enable Segment LCD */
#define L5_LCD_EN                 (* (reg8 *) L5__LCD_EN)
/* Slew Rate Control */
#define L5_SLW                    (* (reg8 *) L5__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define L5_PRTDSI__CAPS_SEL       (* (reg8 *) L5__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define L5_PRTDSI__DBL_SYNC_IN    (* (reg8 *) L5__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define L5_PRTDSI__OE_SEL0        (* (reg8 *) L5__PRTDSI__OE_SEL0) 
#define L5_PRTDSI__OE_SEL1        (* (reg8 *) L5__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define L5_PRTDSI__OUT_SEL0       (* (reg8 *) L5__PRTDSI__OUT_SEL0) 
#define L5_PRTDSI__OUT_SEL1       (* (reg8 *) L5__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define L5_PRTDSI__SYNC_OUT       (* (reg8 *) L5__PRTDSI__SYNC_OUT) 


#if defined(L5__INTSTAT)  /* Interrupt Registers */

    #define L5_INTSTAT                (* (reg8 *) L5__INTSTAT)
    #define L5_SNAP                   (* (reg8 *) L5__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins L5_H */


/* [] END OF FILE */
