/*******************************************************************************
* File Name: L7.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_L7_H) /* Pins L7_H */
#define CY_PINS_L7_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "L7_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    L7_Write(uint8 value) ;
void    L7_SetDriveMode(uint8 mode) ;
uint8   L7_ReadDataReg(void) ;
uint8   L7_Read(void) ;
uint8   L7_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define L7_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define L7_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define L7_DM_RES_UP          PIN_DM_RES_UP
#define L7_DM_RES_DWN         PIN_DM_RES_DWN
#define L7_DM_OD_LO           PIN_DM_OD_LO
#define L7_DM_OD_HI           PIN_DM_OD_HI
#define L7_DM_STRONG          PIN_DM_STRONG
#define L7_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define L7_MASK               L7__MASK
#define L7_SHIFT              L7__SHIFT
#define L7_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define L7_PS                     (* (reg8 *) L7__PS)
/* Data Register */
#define L7_DR                     (* (reg8 *) L7__DR)
/* Port Number */
#define L7_PRT_NUM                (* (reg8 *) L7__PRT) 
/* Connect to Analog Globals */                                                  
#define L7_AG                     (* (reg8 *) L7__AG)                       
/* Analog MUX bux enable */
#define L7_AMUX                   (* (reg8 *) L7__AMUX) 
/* Bidirectional Enable */                                                        
#define L7_BIE                    (* (reg8 *) L7__BIE)
/* Bit-mask for Aliased Register Access */
#define L7_BIT_MASK               (* (reg8 *) L7__BIT_MASK)
/* Bypass Enable */
#define L7_BYP                    (* (reg8 *) L7__BYP)
/* Port wide control signals */                                                   
#define L7_CTL                    (* (reg8 *) L7__CTL)
/* Drive Modes */
#define L7_DM0                    (* (reg8 *) L7__DM0) 
#define L7_DM1                    (* (reg8 *) L7__DM1)
#define L7_DM2                    (* (reg8 *) L7__DM2) 
/* Input Buffer Disable Override */
#define L7_INP_DIS                (* (reg8 *) L7__INP_DIS)
/* LCD Common or Segment Drive */
#define L7_LCD_COM_SEG            (* (reg8 *) L7__LCD_COM_SEG)
/* Enable Segment LCD */
#define L7_LCD_EN                 (* (reg8 *) L7__LCD_EN)
/* Slew Rate Control */
#define L7_SLW                    (* (reg8 *) L7__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define L7_PRTDSI__CAPS_SEL       (* (reg8 *) L7__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define L7_PRTDSI__DBL_SYNC_IN    (* (reg8 *) L7__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define L7_PRTDSI__OE_SEL0        (* (reg8 *) L7__PRTDSI__OE_SEL0) 
#define L7_PRTDSI__OE_SEL1        (* (reg8 *) L7__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define L7_PRTDSI__OUT_SEL0       (* (reg8 *) L7__PRTDSI__OUT_SEL0) 
#define L7_PRTDSI__OUT_SEL1       (* (reg8 *) L7__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define L7_PRTDSI__SYNC_OUT       (* (reg8 *) L7__PRTDSI__SYNC_OUT) 


#if defined(L7__INTSTAT)  /* Interrupt Registers */

    #define L7_INTSTAT                (* (reg8 *) L7__INTSTAT)
    #define L7_SNAP                   (* (reg8 *) L7__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins L7_H */


/* [] END OF FILE */
