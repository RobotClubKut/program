/*******************************************************************************
* File Name: L9.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_L9_H) /* Pins L9_H */
#define CY_PINS_L9_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "L9_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    L9_Write(uint8 value) ;
void    L9_SetDriveMode(uint8 mode) ;
uint8   L9_ReadDataReg(void) ;
uint8   L9_Read(void) ;
uint8   L9_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define L9_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define L9_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define L9_DM_RES_UP          PIN_DM_RES_UP
#define L9_DM_RES_DWN         PIN_DM_RES_DWN
#define L9_DM_OD_LO           PIN_DM_OD_LO
#define L9_DM_OD_HI           PIN_DM_OD_HI
#define L9_DM_STRONG          PIN_DM_STRONG
#define L9_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define L9_MASK               L9__MASK
#define L9_SHIFT              L9__SHIFT
#define L9_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define L9_PS                     (* (reg8 *) L9__PS)
/* Data Register */
#define L9_DR                     (* (reg8 *) L9__DR)
/* Port Number */
#define L9_PRT_NUM                (* (reg8 *) L9__PRT) 
/* Connect to Analog Globals */                                                  
#define L9_AG                     (* (reg8 *) L9__AG)                       
/* Analog MUX bux enable */
#define L9_AMUX                   (* (reg8 *) L9__AMUX) 
/* Bidirectional Enable */                                                        
#define L9_BIE                    (* (reg8 *) L9__BIE)
/* Bit-mask for Aliased Register Access */
#define L9_BIT_MASK               (* (reg8 *) L9__BIT_MASK)
/* Bypass Enable */
#define L9_BYP                    (* (reg8 *) L9__BYP)
/* Port wide control signals */                                                   
#define L9_CTL                    (* (reg8 *) L9__CTL)
/* Drive Modes */
#define L9_DM0                    (* (reg8 *) L9__DM0) 
#define L9_DM1                    (* (reg8 *) L9__DM1)
#define L9_DM2                    (* (reg8 *) L9__DM2) 
/* Input Buffer Disable Override */
#define L9_INP_DIS                (* (reg8 *) L9__INP_DIS)
/* LCD Common or Segment Drive */
#define L9_LCD_COM_SEG            (* (reg8 *) L9__LCD_COM_SEG)
/* Enable Segment LCD */
#define L9_LCD_EN                 (* (reg8 *) L9__LCD_EN)
/* Slew Rate Control */
#define L9_SLW                    (* (reg8 *) L9__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define L9_PRTDSI__CAPS_SEL       (* (reg8 *) L9__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define L9_PRTDSI__DBL_SYNC_IN    (* (reg8 *) L9__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define L9_PRTDSI__OE_SEL0        (* (reg8 *) L9__PRTDSI__OE_SEL0) 
#define L9_PRTDSI__OE_SEL1        (* (reg8 *) L9__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define L9_PRTDSI__OUT_SEL0       (* (reg8 *) L9__PRTDSI__OUT_SEL0) 
#define L9_PRTDSI__OUT_SEL1       (* (reg8 *) L9__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define L9_PRTDSI__SYNC_OUT       (* (reg8 *) L9__PRTDSI__SYNC_OUT) 


#if defined(L9__INTSTAT)  /* Interrupt Registers */

    #define L9_INTSTAT                (* (reg8 *) L9__INTSTAT)
    #define L9_SNAP                   (* (reg8 *) L9__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins L9_H */


/* [] END OF FILE */
