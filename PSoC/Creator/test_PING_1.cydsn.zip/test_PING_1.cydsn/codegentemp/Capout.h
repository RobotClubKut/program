/*******************************************************************************
* File Name: Capout.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Capout_H) /* Pins Capout_H */
#define CY_PINS_Capout_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Capout_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Capout_Write(uint8 value) ;
void    Capout_SetDriveMode(uint8 mode) ;
uint8   Capout_ReadDataReg(void) ;
uint8   Capout_Read(void) ;
uint8   Capout_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Capout_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Capout_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Capout_DM_RES_UP          PIN_DM_RES_UP
#define Capout_DM_RES_DWN         PIN_DM_RES_DWN
#define Capout_DM_OD_LO           PIN_DM_OD_LO
#define Capout_DM_OD_HI           PIN_DM_OD_HI
#define Capout_DM_STRONG          PIN_DM_STRONG
#define Capout_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Capout_MASK               Capout__MASK
#define Capout_SHIFT              Capout__SHIFT
#define Capout_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Capout_PS                     (* (reg8 *) Capout__PS)
/* Data Register */
#define Capout_DR                     (* (reg8 *) Capout__DR)
/* Port Number */
#define Capout_PRT_NUM                (* (reg8 *) Capout__PRT) 
/* Connect to Analog Globals */                                                  
#define Capout_AG                     (* (reg8 *) Capout__AG)                       
/* Analog MUX bux enable */
#define Capout_AMUX                   (* (reg8 *) Capout__AMUX) 
/* Bidirectional Enable */                                                        
#define Capout_BIE                    (* (reg8 *) Capout__BIE)
/* Bit-mask for Aliased Register Access */
#define Capout_BIT_MASK               (* (reg8 *) Capout__BIT_MASK)
/* Bypass Enable */
#define Capout_BYP                    (* (reg8 *) Capout__BYP)
/* Port wide control signals */                                                   
#define Capout_CTL                    (* (reg8 *) Capout__CTL)
/* Drive Modes */
#define Capout_DM0                    (* (reg8 *) Capout__DM0) 
#define Capout_DM1                    (* (reg8 *) Capout__DM1)
#define Capout_DM2                    (* (reg8 *) Capout__DM2) 
/* Input Buffer Disable Override */
#define Capout_INP_DIS                (* (reg8 *) Capout__INP_DIS)
/* LCD Common or Segment Drive */
#define Capout_LCD_COM_SEG            (* (reg8 *) Capout__LCD_COM_SEG)
/* Enable Segment LCD */
#define Capout_LCD_EN                 (* (reg8 *) Capout__LCD_EN)
/* Slew Rate Control */
#define Capout_SLW                    (* (reg8 *) Capout__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Capout_PRTDSI__CAPS_SEL       (* (reg8 *) Capout__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Capout_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Capout__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Capout_PRTDSI__OE_SEL0        (* (reg8 *) Capout__PRTDSI__OE_SEL0) 
#define Capout_PRTDSI__OE_SEL1        (* (reg8 *) Capout__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Capout_PRTDSI__OUT_SEL0       (* (reg8 *) Capout__PRTDSI__OUT_SEL0) 
#define Capout_PRTDSI__OUT_SEL1       (* (reg8 *) Capout__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Capout_PRTDSI__SYNC_OUT       (* (reg8 *) Capout__PRTDSI__SYNC_OUT) 


#if defined(Capout__INTSTAT)  /* Interrupt Registers */

    #define Capout_INTSTAT                (* (reg8 *) Capout__INTSTAT)
    #define Capout_SNAP                   (* (reg8 *) Capout__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins Capout_H */


/* [] END OF FILE */
