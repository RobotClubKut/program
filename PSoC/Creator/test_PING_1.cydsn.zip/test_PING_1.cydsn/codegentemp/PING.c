/*******************************************************************************
* File Name: PING.c  
* Version 1.90
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "PING.h"


/*******************************************************************************
* Function Name: PING_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None 
*  
*******************************************************************************/
void PING_Write(uint8 value) 
{
    uint8 staticBits = (PING_DR & (uint8)(~PING_MASK));
    PING_DR = staticBits | ((uint8)(value << PING_SHIFT) & PING_MASK);
}


/*******************************************************************************
* Function Name: PING_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to this drive mode.
*
* Return: 
*  None
*
*******************************************************************************/
void PING_SetDriveMode(uint8 mode) 
{
	CyPins_SetPinDriveMode(PING_0, mode);
}


/*******************************************************************************
* Function Name: PING_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro PING_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 PING_Read(void) 
{
    return (PING_PS & PING_MASK) >> PING_SHIFT;
}


/*******************************************************************************
* Function Name: PING_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 PING_ReadDataReg(void) 
{
    return (PING_DR & PING_MASK) >> PING_SHIFT;
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(PING_INTSTAT) 

    /*******************************************************************************
    * Function Name: PING_ClearInterrupt
    ********************************************************************************
    *
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 PING_ClearInterrupt(void) 
    {
        return (PING_INTSTAT & PING_MASK) >> PING_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 


/* [] END OF FILE */
