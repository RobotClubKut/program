/*******************************************************************************
* File Name: PING.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PING_H) /* Pins PING_H */
#define CY_PINS_PING_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "PING_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    PING_Write(uint8 value) ;
void    PING_SetDriveMode(uint8 mode) ;
uint8   PING_ReadDataReg(void) ;
uint8   PING_Read(void) ;
uint8   PING_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define PING_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define PING_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define PING_DM_RES_UP          PIN_DM_RES_UP
#define PING_DM_RES_DWN         PIN_DM_RES_DWN
#define PING_DM_OD_LO           PIN_DM_OD_LO
#define PING_DM_OD_HI           PIN_DM_OD_HI
#define PING_DM_STRONG          PIN_DM_STRONG
#define PING_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define PING_MASK               PING__MASK
#define PING_SHIFT              PING__SHIFT
#define PING_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define PING_PS                     (* (reg8 *) PING__PS)
/* Data Register */
#define PING_DR                     (* (reg8 *) PING__DR)
/* Port Number */
#define PING_PRT_NUM                (* (reg8 *) PING__PRT) 
/* Connect to Analog Globals */                                                  
#define PING_AG                     (* (reg8 *) PING__AG)                       
/* Analog MUX bux enable */
#define PING_AMUX                   (* (reg8 *) PING__AMUX) 
/* Bidirectional Enable */                                                        
#define PING_BIE                    (* (reg8 *) PING__BIE)
/* Bit-mask for Aliased Register Access */
#define PING_BIT_MASK               (* (reg8 *) PING__BIT_MASK)
/* Bypass Enable */
#define PING_BYP                    (* (reg8 *) PING__BYP)
/* Port wide control signals */                                                   
#define PING_CTL                    (* (reg8 *) PING__CTL)
/* Drive Modes */
#define PING_DM0                    (* (reg8 *) PING__DM0) 
#define PING_DM1                    (* (reg8 *) PING__DM1)
#define PING_DM2                    (* (reg8 *) PING__DM2) 
/* Input Buffer Disable Override */
#define PING_INP_DIS                (* (reg8 *) PING__INP_DIS)
/* LCD Common or Segment Drive */
#define PING_LCD_COM_SEG            (* (reg8 *) PING__LCD_COM_SEG)
/* Enable Segment LCD */
#define PING_LCD_EN                 (* (reg8 *) PING__LCD_EN)
/* Slew Rate Control */
#define PING_SLW                    (* (reg8 *) PING__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define PING_PRTDSI__CAPS_SEL       (* (reg8 *) PING__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define PING_PRTDSI__DBL_SYNC_IN    (* (reg8 *) PING__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define PING_PRTDSI__OE_SEL0        (* (reg8 *) PING__PRTDSI__OE_SEL0) 
#define PING_PRTDSI__OE_SEL1        (* (reg8 *) PING__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define PING_PRTDSI__OUT_SEL0       (* (reg8 *) PING__PRTDSI__OUT_SEL0) 
#define PING_PRTDSI__OUT_SEL1       (* (reg8 *) PING__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define PING_PRTDSI__SYNC_OUT       (* (reg8 *) PING__PRTDSI__SYNC_OUT) 


#if defined(PING__INTSTAT)  /* Interrupt Registers */

    #define PING_INTSTAT                (* (reg8 *) PING__INTSTAT)
    #define PING_SNAP                   (* (reg8 *) PING__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins PING_H */


/* [] END OF FILE */
