/*******************************************************************************
* File Name: tc.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_tc_H) /* Pins tc_H */
#define CY_PINS_tc_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "tc_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    tc_Write(uint8 value) ;
void    tc_SetDriveMode(uint8 mode) ;
uint8   tc_ReadDataReg(void) ;
uint8   tc_Read(void) ;
uint8   tc_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define tc_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define tc_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define tc_DM_RES_UP          PIN_DM_RES_UP
#define tc_DM_RES_DWN         PIN_DM_RES_DWN
#define tc_DM_OD_LO           PIN_DM_OD_LO
#define tc_DM_OD_HI           PIN_DM_OD_HI
#define tc_DM_STRONG          PIN_DM_STRONG
#define tc_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define tc_MASK               tc__MASK
#define tc_SHIFT              tc__SHIFT
#define tc_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define tc_PS                     (* (reg8 *) tc__PS)
/* Data Register */
#define tc_DR                     (* (reg8 *) tc__DR)
/* Port Number */
#define tc_PRT_NUM                (* (reg8 *) tc__PRT) 
/* Connect to Analog Globals */                                                  
#define tc_AG                     (* (reg8 *) tc__AG)                       
/* Analog MUX bux enable */
#define tc_AMUX                   (* (reg8 *) tc__AMUX) 
/* Bidirectional Enable */                                                        
#define tc_BIE                    (* (reg8 *) tc__BIE)
/* Bit-mask for Aliased Register Access */
#define tc_BIT_MASK               (* (reg8 *) tc__BIT_MASK)
/* Bypass Enable */
#define tc_BYP                    (* (reg8 *) tc__BYP)
/* Port wide control signals */                                                   
#define tc_CTL                    (* (reg8 *) tc__CTL)
/* Drive Modes */
#define tc_DM0                    (* (reg8 *) tc__DM0) 
#define tc_DM1                    (* (reg8 *) tc__DM1)
#define tc_DM2                    (* (reg8 *) tc__DM2) 
/* Input Buffer Disable Override */
#define tc_INP_DIS                (* (reg8 *) tc__INP_DIS)
/* LCD Common or Segment Drive */
#define tc_LCD_COM_SEG            (* (reg8 *) tc__LCD_COM_SEG)
/* Enable Segment LCD */
#define tc_LCD_EN                 (* (reg8 *) tc__LCD_EN)
/* Slew Rate Control */
#define tc_SLW                    (* (reg8 *) tc__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define tc_PRTDSI__CAPS_SEL       (* (reg8 *) tc__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define tc_PRTDSI__DBL_SYNC_IN    (* (reg8 *) tc__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define tc_PRTDSI__OE_SEL0        (* (reg8 *) tc__PRTDSI__OE_SEL0) 
#define tc_PRTDSI__OE_SEL1        (* (reg8 *) tc__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define tc_PRTDSI__OUT_SEL0       (* (reg8 *) tc__PRTDSI__OUT_SEL0) 
#define tc_PRTDSI__OUT_SEL1       (* (reg8 *) tc__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define tc_PRTDSI__SYNC_OUT       (* (reg8 *) tc__PRTDSI__SYNC_OUT) 


#if defined(tc__INTSTAT)  /* Interrupt Registers */

    #define tc_INTSTAT                (* (reg8 *) tc__INTSTAT)
    #define tc_SNAP                   (* (reg8 *) tc__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins tc_H */


/* [] END OF FILE */
