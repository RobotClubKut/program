/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include<stdio.h>
float length(float cnt);
int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
	float k=0;
	char str[60];
	
    CyGlobalIntEnable;  /* Uncomment this line to enable global interrupts. */
	
	UART_Debug_Start();
	Timer_PING_Start();
	timer_clock_Start();
	

	
    for(;;)
    {
		PING_SetDriveMode(PING_DM_STRONG);
		//CyDelay(15);
		PING_Write(0);
		CyDelayUs(2);
		PING_Write(1);
		CyDelayUs(5);
		PING_Write(0);
		PING_SetDriveMode(PING_DM_RES_DWN);
		
		Reset_Write(0x00);
		
		while(!(PING_Read()==1))
		{
			Timer_PING_ClearFIFO();
		}
		while(PING_Read()==1);
		sprintf(str,"cnt = %f\n",length(Timer_PING_ReadCapture()));
		UART_Debug_PutString(str);
		Reset_Write(0x01);
		//CyDelay(500);
		
        /* Place your application code here. */
    }
}
//
float length(float cnt)
{
	float a=0,b=0;
	float ans=0;

	cnt=20000-cnt;
	ans=0.17221*cnt;
	return ans;
}

/* [] END OF FILE */
